/**
 * MediLogit AI - Clinical Decision Support & Diagnostic Triage
 * Core Frontend Application Logic
 */

let confidenceGauge = null;
let lastDiagnosticResult = null;

// ==========================================
// 1. PRESET CLINICAL CASE PROFILES
// ==========================================
const CLINICAL_PRESETS = {
    diabetes: {
        age: 54, gender: 'Male', smoking_history: 'Never', bmi: 31.5,
        systolic_bp: 130, diastolic_bp: 82, heart_rate: 76, body_temperature: 98.6,
        spo2: 98, fasting_blood_sugar: 235,
        symptoms: ['excessive_thirst_polydipsia', 'frequent_urination_polyuria', 'fatigue', 'weight_loss']
    },
    hypertension: {
        age: 58, gender: 'Male', smoking_history: 'Current', bmi: 29.0,
        systolic_bp: 175, diastolic_bp: 108, heart_rate: 88, body_temperature: 98.6,
        spo2: 98, fasting_blood_sugar: 105,
        symptoms: ['headache', 'dizziness', 'palpitations', 'fatigue']
    },
    cad: {
        age: 64, gender: 'Male', smoking_history: 'Current', bmi: 28.2,
        systolic_bp: 152, diastolic_bp: 94, heart_rate: 92, body_temperature: 98.6,
        spo2: 95, fasting_blood_sugar: 110,
        symptoms: ['chest_pain', 'chest_tightness', 'shortness_of_breath', 'palpitations', 'fatigue', 'dizziness']
    },
    covid: {
        age: 36, gender: 'Female', smoking_history: 'Never', bmi: 23.5,
        systolic_bp: 118, diastolic_bp: 76, heart_rate: 94, body_temperature: 102.2,
        spo2: 92, fasting_blood_sugar: 92,
        symptoms: ['loss_of_smell', 'fever', 'cough', 'sore_throat', 'fatigue', 'muscle_pain', 'shortness_of_breath']
    },
    pneumonia: {
        age: 62, gender: 'Male', smoking_history: 'Former', bmi: 26.0,
        systolic_bp: 132, diastolic_bp: 84, heart_rate: 105, body_temperature: 103.4,
        spo2: 89, fasting_blood_sugar: 102,
        symptoms: ['fever', 'chills', 'cough', 'chest_pain', 'shortness_of_breath', 'fatigue']
    },
    gastro: {
        age: 29, gender: 'Female', smoking_history: 'Never', bmi: 22.0,
        systolic_bp: 112, diastolic_bp: 72, heart_rate: 98, body_temperature: 100.8,
        spo2: 99, fasting_blood_sugar: 88,
        symptoms: ['diarrhea', 'vomiting', 'abdominal_pain', 'nausea', 'fatigue', 'fever']
    },
    uti: {
        age: 32, gender: 'Female', smoking_history: 'Never', bmi: 24.0,
        systolic_bp: 118, diastolic_bp: 78, heart_rate: 82, body_temperature: 101.2,
        spo2: 98, fasting_blood_sugar: 90,
        symptoms: ['painful_urination_dysuria', 'frequent_urination_polyuria', 'flank_pain', 'dark_urine', 'fever']
    }
};

document.addEventListener('DOMContentLoaded', () => {
    initThemeToggle();
    initVitalDynamicBadges();
    initSymptomSearchAndCategory();
    initPresetButtons();
    initDiagnosisForm();
    initReportModal();
    initBatchUpload();
});

// ==========================================
// 2. THEME & PALETTE TOGGLE
// ==========================================
function initThemeToggle() {
    // 2.1 Dark / Light Mode with localStorage persistence
    const btn = document.getElementById('themeToggle');
    const savedTheme = localStorage.getItem('medilogit_bs_theme') || 'light';
    document.documentElement.setAttribute('data-bs-theme', savedTheme);
    if (btn) {
        btn.innerHTML = savedTheme === 'dark' ? '<i class="fa-solid fa-sun text-warning"></i>' : '<i class="fa-solid fa-moon"></i>';
        btn.addEventListener('click', () => {
            const current = document.documentElement.getAttribute('data-bs-theme');
            const next = current === 'dark' ? 'light' : 'dark';
            document.documentElement.setAttribute('data-bs-theme', next);
            localStorage.setItem('medilogit_bs_theme', next);
            btn.innerHTML = next === 'dark' ? '<i class="fa-solid fa-sun text-warning"></i>' : '<i class="fa-solid fa-moon"></i>';
        });
    }

    // 2.2 UI Color Palette Switcher with persistence
    const themeLabels = {
        'default': 'Classic Blue',
        'emerald': 'Emerald Teal',
        'purple': 'Royal Violet',
        'crimson': 'Crimson Rose',
        'slate': 'Slate Steel'
    };
    const savedColor = localStorage.getItem('medilogit_color_theme') || 'default';
    if (savedColor !== 'default') {
        document.documentElement.setAttribute('data-ui-theme', savedColor);
    } else {
        document.documentElement.removeAttribute('data-ui-theme');
    }
    const currentLabel = document.getElementById('currentThemeLabel');
    if (currentLabel) {
        currentLabel.textContent = themeLabels[savedColor] || 'Classic Blue';
    }

    document.querySelectorAll('.theme-choice-btn').forEach(choiceBtn => {
        choiceBtn.addEventListener('click', () => {
            const chosen = choiceBtn.getAttribute('data-color-theme');
            if (chosen === 'default') {
                document.documentElement.removeAttribute('data-ui-theme');
            } else {
                document.documentElement.setAttribute('data-ui-theme', chosen);
            }
            localStorage.setItem('medilogit_color_theme', chosen);
            if (currentLabel) {
                currentLabel.textContent = themeLabels[chosen] || 'Classic Blue';
            }
        });
    });
}

// ==========================================
// 3. VITAL SIGNS & DYNAMIC STATUS BADGES
// ==========================================
function initVitalDynamicBadges() {
    const sysInput = document.getElementById('systolic_bp');
    const diaInput = document.getElementById('diastolic_bp');
    const bmiInput = document.getElementById('bmi');
    const hrInput = document.getElementById('heart_rate');
    const tempInput = document.getElementById('body_temperature');
    const spo2Input = document.getElementById('spo2');
    const fbsInput = document.getElementById('fasting_blood_sugar');

    function updateVitals() {
        if (sysInput && diaInput) {
            const sysVal = sysInput.value.trim();
            const diaVal = diaInput.value.trim();
            const sysBadge = document.getElementById('sysBpBadge');
            const diaBadge = document.getElementById('diaBpBadge');
            
            if (sysBadge) {
                if (!sysVal) {
                    sysBadge.className = 'badge bg-light text-muted fw-normal';
                    sysBadge.textContent = '-- mmHg';
                } else {
                    const sys = parseInt(sysVal);
                    if (sys >= 180) { sysBadge.className = 'badge bg-danger text-white'; sysBadge.textContent = `${sys} Crisis`; }
                    else if (sys >= 140) { sysBadge.className = 'badge bg-warning text-dark'; sysBadge.textContent = `${sys} Stage 2`; }
                    else if (sys >= 130) { sysBadge.className = 'badge bg-info-subtle text-info'; sysBadge.textContent = `${sys} Stage 1`; }
                    else { sysBadge.className = 'badge bg-light text-dark'; sysBadge.textContent = `${sys} Normal`; }
                }
            }
            if (diaBadge) {
                if (!diaVal) {
                    diaBadge.className = 'badge bg-light text-muted fw-normal';
                    diaBadge.textContent = '-- mmHg';
                } else {
                    const dia = parseInt(diaVal);
                    if (dia >= 120) { diaBadge.className = 'badge bg-danger text-white'; diaBadge.textContent = `${dia} Crisis`; }
                    else if (dia >= 90) { diaBadge.className = 'badge bg-warning text-dark'; diaBadge.textContent = `${dia} Stage 2`; }
                    else { diaBadge.className = 'badge bg-light text-dark'; diaBadge.textContent = `${dia} Normal`; }
                }
            }
        }

        if (bmiInput) {
            const bmiVal = bmiInput.value.trim();
            const badge = document.getElementById('bmiBadge');
            if (badge) {
                if (!bmiVal) {
                    badge.className = 'badge bg-light text-muted fw-normal';
                    badge.textContent = '-- Norm';
                } else {
                    const bmi = parseFloat(bmiVal);
                    if (bmi >= 30) { badge.className = 'badge bg-danger text-white'; badge.textContent = `${bmi} Obese`; }
                    else if (bmi >= 25) { badge.className = 'badge bg-warning text-dark'; badge.textContent = `${bmi} Overwt`; }
                    else if (bmi < 18.5) { badge.className = 'badge bg-info-subtle text-info'; badge.textContent = `${bmi} Underwt`; }
                    else { badge.className = 'badge bg-light text-dark'; badge.textContent = `${bmi} Normal`; }
                }
            }
        }

        if (hrInput) {
            const hrVal = hrInput.value.trim();
            const badge = document.getElementById('hrBadge');
            if (badge) {
                if (!hrVal) {
                    badge.className = 'badge bg-light text-muted fw-normal';
                    badge.textContent = '-- bpm';
                } else {
                    const hr = parseInt(hrVal);
                    if (hr > 120) { badge.className = 'badge bg-danger text-white'; badge.textContent = `${hr} Tachycardia`; }
                    else if (hr < 50) { badge.className = 'badge bg-warning text-dark'; badge.textContent = `${hr} Bradycardia`; }
                    else { badge.className = 'badge bg-light text-dark'; badge.textContent = `${hr} Normal`; }
                }
            }
        }

        if (tempInput) {
            const tempVal = tempInput.value.trim();
            const badge = document.getElementById('tempBadge');
            if (badge) {
                if (!tempVal) {
                    badge.className = 'badge bg-light text-muted fw-normal';
                    badge.textContent = '-- °F';
                } else {
                    const temp = parseFloat(tempVal);
                    if (temp >= 103.0) { badge.className = 'badge bg-danger text-white'; badge.textContent = `${temp}°F High Fever`; }
                    else if (temp >= 100.4) { badge.className = 'badge bg-warning text-dark'; badge.textContent = `${temp}°F Fever`; }
                    else { badge.className = 'badge bg-light text-dark'; badge.textContent = `${temp}°F Normal`; }
                }
            }
        }

        if (spo2Input) {
            const spo2Val = spo2Input.value.trim();
            const badge = document.getElementById('spo2Badge');
            if (badge) {
                if (!spo2Val) {
                    badge.className = 'badge bg-light text-muted fw-normal';
                    badge.textContent = '-- %';
                } else {
                    const spo2 = parseInt(spo2Val);
                    if (spo2 < 90) { badge.className = 'badge bg-danger text-white'; badge.textContent = `${spo2}% Critical`; }
                    else if (spo2 <= 93) { badge.className = 'badge bg-warning text-dark'; badge.textContent = `${spo2}% Low`; }
                    else { badge.className = 'badge bg-light text-dark'; badge.textContent = `${spo2}% Normal`; }
                }
            }
        }

        if (fbsInput) {
            const fbsVal = fbsInput.value.trim();
            const badge = document.getElementById('fbsBadge');
            if (badge) {
                if (!fbsVal) {
                    badge.className = 'badge bg-light text-muted fw-normal';
                    badge.textContent = '-- mg/dL';
                } else {
                    const fbs = parseInt(fbsVal);
                    if (fbs >= 200) { badge.className = 'badge bg-danger text-white'; badge.textContent = `${fbs} Diabetic High`; }
                    else if (fbs >= 126) { badge.className = 'badge bg-warning text-dark'; badge.textContent = `${fbs} Elevated`; }
                    else if (fbs < 70) { badge.className = 'badge bg-danger text-white'; badge.textContent = `${fbs} Hypoglycemia`; }
                    else { badge.className = 'badge bg-light text-dark'; badge.textContent = `${fbs} Normal`; }
                }
            }
        }
    }

    document.querySelectorAll('.vital-input').forEach(input => {
        input.addEventListener('input', updateVitals);
    });
    updateVitals();
}

// ==========================================
// 4. SYMPTOM SEARCH & ACTIVE COUNT
// ==========================================
function initSymptomSearchAndCategory() {
    const searchInput = document.getElementById('symptomSearchInput');
    const clearBtn = document.getElementById('clearSymptomSearch');
    const symptomItems = document.querySelectorAll('.symptom-item');

    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase().trim();
            symptomItems.forEach(item => {
                const title = item.getAttribute('data-title') || '';
                if (title.includes(query)) {
                    item.classList.remove('d-none');
                } else {
                    item.classList.add('d-none');
                }
            });
        });
    }

    if (clearBtn && searchInput) {
        clearBtn.addEventListener('click', () => {
            searchInput.value = '';
            symptomItems.forEach(item => item.classList.remove('d-none'));
        });
    }

    // Checkbox active styling & counter
    const checkboxes = document.querySelectorAll('.symptom-checkbox');
    checkboxes.forEach(cb => {
        cb.addEventListener('change', () => {
            const parentCard = cb.closest('.symptom-card');
            if (parentCard) {
                if (cb.checked) parentCard.classList.add('active');
                else parentCard.classList.remove('active');
            }
            updateActiveSymptomCount();
        });
    });

    // Select all per category
    document.querySelectorAll('.select-all-cat-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const targetId = btn.getAttribute('data-target');
            const targetContainer = document.getElementById(targetId);
            if (!targetContainer) return;
            const cbs = targetContainer.querySelectorAll('.symptom-checkbox');
            const anyUnchecked = Array.from(cbs).some(c => !c.checked);
            cbs.forEach(c => {
                c.checked = anyUnchecked;
                const card = c.closest('.symptom-card');
                if (card) {
                    if (anyUnchecked) card.classList.add('active');
                    else card.classList.remove('active');
                }
            });
            updateActiveSymptomCount();
        });
    });
}

function updateActiveSymptomCount() {
    const checked = document.querySelectorAll('.symptom-checkbox:checked').length;
    const badge = document.getElementById('activeSymptomCount');
    if (badge) {
        badge.textContent = `${checked} Symptom${checked === 1 ? '' : 's'} Selected`;
        badge.className = checked > 0 ? 'badge bg-primary text-white rounded-pill px-3 py-1' : 'badge bg-secondary text-white rounded-pill px-3 py-1';
    }
}

// ==========================================
// 5. PRESET CASE LOADER
// ==========================================
function initPresetButtons() {
    document.querySelectorAll('.preset-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const presetKey = btn.getAttribute('data-preset');
            const data = CLINICAL_PRESETS[presetKey];
            if (!data) return;

            // Clear checkboxes
            document.querySelectorAll('.symptom-checkbox').forEach(cb => {
                cb.checked = false;
                const card = cb.closest('.symptom-card');
                if (card) card.classList.remove('active');
            });

            // Set inputs
            for (const [k, v] of Object.entries(data)) {
                if (k === 'symptoms') {
                    v.forEach(symId => {
                        const cb = document.getElementById(symId);
                        if (cb) {
                            cb.checked = true;
                            const card = cb.closest('.symptom-card');
                            if (card) card.classList.add('active');
                        }
                    });
                } else {
                    const el = document.getElementById(k);
                    if (el) el.value = v;
                }
            }

            updateActiveSymptomCount();
            // Trigger vitals update
            const sys = document.getElementById('systolic_bp');
            if (sys) sys.dispatchEvent(new Event('input'));

            // Auto-submit preset for immediate clinical demonstration
            const form = document.getElementById('diagnosisForm');
            if (form) form.dispatchEvent(new Event('submit'));
        });
    });

    const resetBtn = document.getElementById('resetFormBtn');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            const form = document.getElementById('diagnosisForm');
            if (form) form.reset();
            document.querySelectorAll('.symptom-card').forEach(c => c.classList.remove('active'));
            updateActiveSymptomCount();
            const sys = document.getElementById('systolic_bp');
            if (sys) sys.dispatchEvent(new Event('input'));
            
            // Hide active panel and show placeholder
            document.getElementById('activeResultPanel').classList.add('d-none');
            document.getElementById('emptyResultPlaceholder').classList.remove('d-none');
        });
    }
}

// ==========================================
// 6. ASYNC DIAGNOSIS INFERENCE & RENDERING
// ==========================================
function initDiagnosisForm() {
    const form = document.getElementById('diagnosisForm');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const btn = document.getElementById('submitBtn');
        const spinner = document.getElementById('btnSpinner');
        const btnText = document.getElementById('btnText');

        if (btn && spinner && btnText) {
            btn.disabled = true;
            spinner.classList.remove('d-none');
            btnText.textContent = 'Computing Softmax Probabilities...';
        }

        // Build Payload with intelligent clinical baseline fallbacks
        const formData = new FormData(form);
        const payload = {
            age: formData.get('age') || 45,
            gender: formData.get('gender') || 'Male',
            smoking_history: formData.get('smoking_history') || 'Never',
            bmi: formData.get('bmi') || 24.5,
            systolic_bp: formData.get('systolic_bp') || 120,
            diastolic_bp: formData.get('diastolic_bp') || 80,
            heart_rate: formData.get('heart_rate') || 72,
            body_temperature: formData.get('body_temperature') || 98.6,
            spo2: formData.get('spo2') || 98,
            fasting_blood_sugar: formData.get('fasting_blood_sugar') || 95
        };

        // Set all unselected symptoms to 0
        document.querySelectorAll('.symptom-checkbox').forEach(cb => {
            payload[cb.name] = cb.checked ? 1 : 0;
        });

        try {
            const response = await fetch('/api/predict', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            const res = await response.json();

            if (res.success) {
                lastDiagnosticResult = res.data;
                renderDiagnosticResult(res.data);
            } else {
                alert('Diagnostic error: ' + res.error);
            }
        } catch (err) {
            console.error(err);
            alert('Failed to connect to diagnostic inference server.');
        } finally {
            if (btn && spinner && btnText) {
                btn.disabled = false;
                spinner.classList.add('d-none');
                btnText.textContent = 'Compute Multinomial Disease Diagnosis';
            }
        }
    });
}

function renderDiagnosticResult(data) {
    const placeholder = document.getElementById('emptyResultPlaceholder');
    const resultPanel = document.getElementById('activeResultPanel');
    if (placeholder) placeholder.classList.add('d-none');
    if (resultPanel) resultPanel.classList.remove('d-none');

    const pred = data.prediction;
    const triage = data.triage;
    const guidelines = data.clinical_guidelines;
    const explain = data.explainability;

    // Header Details
    document.getElementById('topDiseaseTitle').textContent = pred.top_disease;
    document.getElementById('diseaseFullName').textContent = guidelines.full_name || pred.top_disease;
    document.getElementById('diseaseCategoryBadge').textContent = guidelines.category || 'General Medicine';
    document.getElementById('confidencePercent').textContent = `${pred.confidence_percentage}%`;
    document.getElementById('specialistText').innerHTML = `<i class="fa-solid fa-user-doctor me-1"></i> ${guidelines.specialist}`;
    document.getElementById('urgencyText').textContent = `${guidelines.urgency} Urgency`;

    // Triage Badge & Card Color
    const headerCard = document.getElementById('resultHeaderCard');
    const triageBadge = document.getElementById('triageAlertBadge');
    
    triageBadge.className = 'triage-badge';
    if (triage.risk_level === 'CRITICAL EMERGENCY') {
        triageBadge.classList.add('triage-critical');
        triageBadge.textContent = 'CRITICAL EMERGENCY';
        headerCard.style.background = 'linear-gradient(135deg, #7f1d1d 0%, #b91c1c 100%)';
    } else if (triage.risk_level === 'HIGH') {
        triageBadge.classList.add('triage-high');
        triageBadge.textContent = 'HIGH RISK ALERT';
        headerCard.style.background = 'linear-gradient(135deg, #991b1b 0%, #dc2626 100%)';
    } else if (triage.risk_level === 'MODERATE') {
        triageBadge.classList.add('triage-moderate');
        triageBadge.textContent = 'MODERATE RISK';
        headerCard.style.background = 'linear-gradient(135deg, #b45309 0%, #f59e0b 100%)';
    } else {
        triageBadge.classList.add('triage-low');
        triageBadge.textContent = 'LOW RISK';
        headerCard.style.background = 'linear-gradient(135deg, #047857 0%, #10b981 100%)';
    }

    // Clinical Warnings
    const warnContainer = document.getElementById('clinicalWarningsContainer');
    const warnList = document.getElementById('clinicalWarningsList');
    if (triage.clinical_warnings && triage.clinical_warnings.length > 0) {
        warnContainer.classList.remove('d-none');
        warnList.innerHTML = triage.clinical_warnings.map(w => `<li>${w}</li>`).join('');
    } else {
        warnContainer.classList.add('d-none');
        warnList.innerHTML = '';
    }

    // Gauge Chart
    renderConfidenceGauge(pred.confidence_percentage);

    // Differential Diagnoses
    const diffContainer = document.getElementById('differentialListContainer');
    diffContainer.innerHTML = pred.differential_diagnoses.map((d, idx) => `
        <div class="differential-row">
            <div class="d-flex justify-content-between align-items-center mb-1 small">
                <span class="fw-semibold text-dark">
                    <span class="badge bg-secondary-subtle text-secondary me-1">#${idx+1}</span>
                    ${d.disease}
                </span>
                <span class="fw-bold ${idx === 0 ? 'text-primary' : 'text-secondary'}">${d.probability}%</span>
            </div>
            <div class="w-100 bg-light rounded-pill overflow-hidden" style="height: 6px;">
                <div class="diff-bar-fill" style="width: ${Math.max(d.probability, 2)}%;"></div>
            </div>
        </div>
    `).join('');

    // Explainability Indicators
    const explainList = document.getElementById('explainabilityList');
    let explainHtml = '';
    explain.positive_indicators.forEach(item => {
        explainHtml += `
            <div class="contrib-pill contrib-pos">
                <span class="fw-medium text-dark"><i class="fa-solid fa-plus-circle text-success me-1"></i> ${item.label}</span>
                <span class="badge bg-success-subtle text-success">Weight: +${item.weight} (OR: ${item.contribution_score > 0 ? (Math.exp(Math.min(item.weight, 5))).toFixed(1) : '1.0'}x)</span>
            </div>
        `;
    });
    if (explain.negative_indicators.length > 0) {
        explain.negative_indicators.forEach(item => {
            explainHtml += `
                <div class="contrib-pill contrib-neg">
                    <span class="fw-medium text-dark"><i class="fa-solid fa-minus-circle text-danger me-1"></i> ${item.label}</span>
                    <span class="badge bg-danger-subtle text-danger">Weight: ${item.weight}</span>
                </div>
            `;
        });
    }
    explainList.innerHTML = explainHtml || '<p class="text-muted small mb-0">No strong outlier weights.</p>';

    // Recommended Tests
    const testsList = document.getElementById('recommendedTestsList');
    testsList.innerHTML = guidelines.recommended_tests.map(t => `
        <li class="mb-1 d-flex align-items-center gap-2">
            <i class="fa-solid fa-circle-check text-primary"></i> <span>${t}</span>
        </li>
    `).join('');

    // Precautions
    const precautionsList = document.getElementById('precautionsList');
    precautionsList.innerHTML = guidelines.precautions.map(p => `
        <li class="mb-1 d-flex align-items-center gap-2">
            <i class="fa-solid fa-shield-halved text-danger"></i> <span>${p}</span>
        </li>
    `).join('');

    // Lifestyle & Diet
    document.getElementById('dietAdviceText').textContent = guidelines.lifestyle_diet || 'Maintain well-balanced nutrition and hydration.';

    // Scroll smoothly to results on mobile devices
    if (window.innerWidth < 992) {
        resultPanel.scrollIntoView({ behavior: 'smooth' });
    }
}

function renderConfidenceGauge(percentage) {
    const ctx = document.getElementById('confidenceGaugeChart');
    if (!ctx) return;

    if (confidenceGauge) {
        confidenceGauge.destroy();
    }

    const remaining = Math.max(0, 100 - percentage);
    confidenceGauge = new Chart(ctx, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [percentage, remaining],
                backgroundColor: ['#1a56db', '#e2e8f0'],
                borderWidth: 0,
                circumference: 360,
                rotation: 0
            }]
        },
        options: {
            cutout: '78%',
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                tooltip: { enabled: false }
            }
        }
    });
}

// ==========================================
// 7. PRINTABLE SUMMARY REPORT MODAL
// ==========================================
function initReportModal() {
    const printBtn = document.getElementById('printReportBtn');
    const shareBtn = document.getElementById('shareReportBtn');

    if (printBtn) {
        printBtn.addEventListener('click', () => {
            if (!lastDiagnosticResult) return;
            generateModalReport(lastDiagnosticResult);
            const modal = new bootstrap.Modal(document.getElementById('reportModal'));
            modal.show();
        });
    }

    if (shareBtn) {
        shareBtn.addEventListener('click', () => {
            if (!lastDiagnosticResult) return;
            const pred = lastDiagnosticResult.prediction;
            const text = `MediLogit AI Clinical Diagnosis\nDiagnosis: ${pred.top_disease} (${pred.confidence_percentage}% Confidence)\nRisk Level: ${lastDiagnosticResult.triage.risk_level}\nReferred Specialist: ${lastDiagnosticResult.clinical_guidelines.specialist}`;
            navigator.clipboard.writeText(text).then(() => {
                alert('Clinical diagnosis summary copied to clipboard!');
            });
        });
    }
}

function generateModalReport(data) {
    const modalBody = document.getElementById('modalReportBody');
    const pred = data.prediction;
    const triage = data.triage;
    const guide = data.clinical_guidelines;

    modalBody.innerHTML = `
        <div class="row g-3 mb-3">
            <div class="col-6">
                <div class="p-3 bg-light rounded-3">
                    <span class="text-muted tiny d-block">PRIMARY DIAGNOSIS</span>
                    <h5 class="fw-bold text-primary mb-0">${pred.top_disease}</h5>
                    <span class="badge bg-primary text-white mt-1">${pred.confidence_percentage}% Confidence</span>
                </div>
            </div>
            <div class="col-6">
                <div class="p-3 bg-light rounded-3">
                    <span class="text-muted tiny d-block">CLINICAL TRIAGE STATUS</span>
                    <h5 class="fw-bold text-danger mb-0">${triage.risk_level}</h5>
                    <span class="text-muted small">Specialist: ${guide.specialist}</span>
                </div>
            </div>
        </div>

        <div class="mb-3">
            <h6 class="fw-bold text-dark border-bottom pb-1">Recommended Laboratory & Diagnostic Tests</h6>
            <ul class="small text-secondary ps-3 mb-0">
                ${guide.recommended_tests.map(t => `<li>${t}</li>`).join('')}
            </ul>
        </div>

        <div class="mb-3">
            <h6 class="fw-bold text-dark border-bottom pb-1">Essential Clinical Precautions</h6>
            <ul class="small text-secondary ps-3 mb-0">
                ${guide.precautions.map(p => `<li>${p}</li>`).join('')}
            </ul>
        </div>

        <div class="mb-3">
            <h6 class="fw-bold text-dark border-bottom pb-1">Lifestyle & Dietary Protocol</h6>
            <p class="small text-secondary mb-0">${guide.lifestyle_diet}</p>
        </div>
    `;
}

// ==========================================
// 8. BATCH CSV UPLOAD & PROCESSING
// ==========================================
let batchCohortChart = null;

function initBatchUpload() {
    const form = document.getElementById('batchUploadForm');
    const fileInput = document.getElementById('csvFileInput');
    const dropZone = document.getElementById('dropZone');
    const dropText = document.getElementById('dropZoneText');
    const processBtn = document.getElementById('processBatchBtn');
    const clearBtn = document.getElementById('clearBatchBtn');

    if (!form || !fileInput) return;

    fileInput.addEventListener('change', () => {
        if (fileInput.files.length > 0) {
            const fileName = fileInput.files[0].name;
            dropText.innerHTML = `<span class="text-primary fw-bold"><i class="fa-solid fa-file-csv me-1"></i> ${fileName}</span>`;
            processBtn.disabled = false;
            clearBtn.disabled = false;
        }
    });

    if (dropZone) {
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            if (e.dataTransfer.files.length > 0) {
                fileInput.files = e.dataTransfer.files;
                fileInput.dispatchEvent(new Event('change'));
            }
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            form.reset();
            dropText.textContent = 'Drag & Drop Patient CSV here or click to browse';
            processBtn.disabled = true;
            clearBtn.disabled = true;
            document.getElementById('batchResultsSection').classList.add('d-none');
        });
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(form);
        const spinner = document.getElementById('batchBtnSpinner');
        const btnText = document.getElementById('batchBtnText');

        processBtn.disabled = true;
        spinner.classList.remove('d-none');
        btnText.textContent = 'Processing Cohort...';

        try {
            const response = await fetch('/api/batch-predict', {
                method: 'POST',
                body: formData
            });
            const data = await response.json();

            if (data.success) {
                renderBatchResults(data);
            } else {
                alert('Batch processing error: ' + data.error);
            }
        } catch (err) {
            console.error(err);
            alert('Failed to process batch CSV.');
        } finally {
            processBtn.disabled = false;
            spinner.classList.add('d-none');
            btnText.innerHTML = '<i class="fa-solid fa-bolt me-1"></i> Process Batch Diagnostics';
        }
    });

    // Table search
    const tableSearch = document.getElementById('tableSearchInput');
    if (tableSearch) {
        tableSearch.addEventListener('input', (e) => {
            const q = e.target.value.toLowerCase();
            const rows = document.querySelectorAll('#batchTableBody tr');
            rows.forEach(r => {
                r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
            });
        });
    }

    // Export Table CSV
    const exportBtn = document.getElementById('exportTableCsvBtn');
    if (exportBtn) {
        exportBtn.addEventListener('click', () => {
            const rows = document.querySelectorAll('#batchResultsTable tr');
            let csvContent = '';
            rows.forEach(r => {
                const cols = r.querySelectorAll('th, td');
                const rowData = Array.from(cols).map(c => `"${c.innerText.replace(/"/g, '""')}"`).join(',');
                csvContent += rowData + '\r\n';
            });
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            link.href = URL.createObjectURL(blob);
            link.setAttribute('download', 'patient_triage_results.csv');
            link.click();
        });
    }
}

function renderBatchResults(data) {
    const section = document.getElementById('batchResultsSection');
    if (!section) return;
    section.classList.remove('d-none');

    // KPIs
    document.getElementById('totalProcessedKpi').textContent = data.total_records;
    const criticalCount = data.results.filter(r => r.risk_level === 'CRITICAL EMERGENCY' || r.risk_level === 'HIGH').length;
    document.getElementById('criticalRiskKpi').textContent = criticalCount;
    document.getElementById('uniqueDiseasesKpi').textContent = Object.keys(data.class_distribution).length;

    // Table
    const tbody = document.getElementById('batchTableBody');
    tbody.innerHTML = data.results.map(r => `
        <tr>
            <td class="fw-bold">#${r.record_id}</td>
            <td>Age: ${r.age} | ${r.gender}</td>
            <td class="fw-bold text-primary">${r.top_diagnosis}</td>
            <td><span class="badge bg-light text-dark">${r.confidence}</span></td>
            <td>
                <span class="badge ${r.risk_level.includes('CRITICAL') ? 'bg-danger' : r.risk_level.includes('HIGH') ? 'bg-danger-subtle text-danger' : 'bg-success-subtle text-success'}">
                    ${r.risk_level}
                </span>
            </td>
            <td>${r.specialist}</td>
            <td class="text-truncate" style="max-width: 180px;" title="${r.primary_symptoms}">${r.primary_symptoms}</td>
        </tr>
    `).join('');

    // Cohort Chart
    const ctx = document.getElementById('batchCohortChart');
    if (ctx) {
        if (batchCohortChart) batchCohortChart.destroy();
        const labels = Object.keys(data.class_distribution);
        const counts = Object.values(data.class_distribution);

        batchCohortChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: counts,
                    backgroundColor: [
                        '#1a56db', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
                        '#06b6d4', '#ec4899', '#6366f1', '#14b8a6', '#f97316'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { boxWidth: 12, font: { size: 10 } } }
                }
            }
        });
    }
}
