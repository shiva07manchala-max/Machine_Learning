/**
 * MediLogit AI - Analytics & Research Visualizations
 * Renders Benchmark Comparisons, Training Convergence Curves, and Odds Ratios Explorer
 */

document.addEventListener('DOMContentLoaded', () => {
    if (typeof MODEL_METADATA === 'undefined') return;

    initBenchmarkChart();
    initLearningCurvesChart();
    initOddsRatioExplorer();
});

// ==========================================
// 1. BENCHMARK COMPARISON BAR CHART
// ==========================================
function initBenchmarkChart() {
    const ctx = document.getElementById('benchmarkBarChart');
    if (!ctx) return;

    const benchmarks = MODEL_METADATA.benchmark_comparison || [];
    const labels = benchmarks.map(b => b.model_name.replace(' (Ensemble Trees)', '').replace(' (Tuned)', '').replace(' (k=7)', ''));
    const accuracies = benchmarks.map(b => b.accuracy);
    const f1s = benchmarks.map(b => (b.f1_macro * 100).toFixed(1));

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Accuracy (%)',
                    data: accuracies,
                    backgroundColor: '#1a56db',
                    borderRadius: 6
                },
                {
                    label: 'Macro F1 (%)',
                    data: f1s,
                    backgroundColor: '#10b981',
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    min: 90,
                    max: 100,
                    ticks: { callback: v => v + '%' }
                }
            },
            plugins: {
                legend: { position: 'top' }
            }
        }
    });
}

// ==========================================
// 2. LEARNING CONVERGENCE CURVES
// ==========================================
function initLearningCurvesChart() {
    const ctx = document.getElementById('learningCurvesChart');
    if (!ctx) return;

    const history = MODEL_METADATA.training_history || { loss: [], accuracy: [] };
    const step = Math.max(1, Math.floor(history.loss.length / 50));
    const sampledLoss = [];
    const sampledAcc = [];
    const sampledLabels = [];

    for (let i = 0; i < history.loss.length; i += step) {
        sampledLoss.push(history.loss[i]);
        sampledAcc.push((history.accuracy[i] * 100).toFixed(1));
        sampledLabels.push(`Ep ${i+1}`);
    }

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: sampledLabels,
            datasets: [
                {
                    label: 'Cross-Entropy Loss',
                    data: sampledLoss,
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    yAxisID: 'yLoss',
                    tension: 0.3,
                    fill: false
                },
                {
                    label: 'Training Accuracy (%)',
                    data: sampledAcc,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    yAxisID: 'yAcc',
                    tension: 0.3,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: { mode: 'index', intersect: false },
            scales: {
                yLoss: {
                    type: 'linear',
                    position: 'left',
                    title: { display: true, text: 'Loss' }
                },
                yAcc: {
                    type: 'linear',
                    position: 'right',
                    title: { display: true, text: 'Accuracy (%)' },
                    grid: { drawOnChartArea: false },
                    min: 50,
                    max: 100
                }
            },
            plugins: {
                legend: { position: 'top' }
            }
        }
    });
}

// ==========================================
// 3. ODDS RATIO EXPLORER
// ==========================================
function initOddsRatioExplorer() {
    const select = document.getElementById('oddsRatioDiseaseSelect');
    const container = document.getElementById('oddsRatioDisplayContainer');
    if (!select || !container) return;

    function renderDiseaseOddsRatios(diseaseName) {
        const weightsData = MODEL_METADATA.class_feature_weights[diseaseName];
        if (!weightsData) return;

        let html = `
            <div class="mb-2 p-2 bg-light rounded-3 d-flex justify-content-between align-items-center">
                <span class="small fw-semibold text-secondary">Model Intercept ($b_k$):</span>
                <span class="badge bg-secondary">${weightsData.intercept}</span>
            </div>
            <span class="tiny text-muted fw-semibold d-block mt-2 mb-1">TOP POSITIVE PREDICTIVE BIOMARKERS & SYMPTOMS ($e^{\\beta} > 1.0$)</span>
        `;

        weightsData.top_positive_features.forEach(feat => {
            const cleanName = feat.feature.replace(/_/g, ' ').toUpperCase();
            html += `
                <div class="d-flex justify-content-between align-items-center p-2 bg-white rounded-3 border mb-1 small">
                    <span class="fw-semibold text-dark"><i class="fa-solid fa-arrow-up-right-dots text-success me-1"></i> ${cleanName}</span>
                    <div class="d-flex gap-2 align-items-center">
                        <span class="text-muted tiny">Coef: +${feat.coefficient}</span>
                        <span class="badge bg-success-subtle text-success fw-bold">OR: ${feat.odds_ratio}x</span>
                    </div>
                </div>
            `;
        });

        html += `<span class="tiny text-muted fw-semibold d-block mt-3 mb-1">NEGATIVE / PROTECTIVE DETERRENT INDICATORS</span>`;
        weightsData.top_negative_features.forEach(feat => {
            const cleanName = feat.feature.replace(/_/g, ' ').toUpperCase();
            html += `
                <div class="d-flex justify-content-between align-items-center p-2 bg-white rounded-3 border mb-1 small">
                    <span class="fw-semibold text-dark"><i class="fa-solid fa-arrow-down-right-dots text-danger me-1"></i> ${cleanName}</span>
                    <div class="d-flex gap-2 align-items-center">
                        <span class="text-muted tiny">Coef: ${feat.coefficient}</span>
                        <span class="badge bg-danger-subtle text-danger fw-bold">OR: ${feat.odds_ratio}x</span>
                    </div>
                </div>
            `;
        });

        container.innerHTML = html;
    }

    select.addEventListener('change', (e) => {
        renderDiseaseOddsRatios(e.target.value);
    });

    // Render initial disease
    renderDiseaseOddsRatios(select.value);
}
