@echo off
title MediLogit AI - Multi-Class Disease Diagnosis
echo ===================================================================
echo   MediLogit AI: Multi-Class Disease Diagnosis Clinical System
echo   Multinomial Logistic Regression with Softmax Link & Explainability
echo ===================================================================
echo.

cd /d "%~dp0"

echo Checking Python environment...
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not added to PATH.
    echo Please install Python 3.9 or higher and try again.
    pause
    exit /b
)

echo.
echo Starting Web Server at http://127.0.0.1:5000 ...
echo Press Ctrl+C in this terminal to stop the server.
echo.

python app.py
pause
