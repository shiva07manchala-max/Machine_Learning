# 🩺 Multi-Class Disease Diagnosis Using Multinomial Logistic Regression

[![Machine Learning](https://img.shields.io/badge/Machine%20Learning-Multinomial%20Logistic%20Regression-blue.svg)](https://scikit-learn.org/)
[![Model Accuracy](https://img.shields.io/badge/Test%20Accuracy-98.98%25-brightgreen.svg)]()
[![Macro ROC-AUC](https://img.shields.io/badge/Macro%20ROC--AUC-0.9999-success.svg)]()
[![Target Pathologies](https://img.shields.io/badge/Target%20Diseases-18%20Classes-orange.svg)]()
[![Web Framework](https://img.shields.io/badge/Backend-Flask%20%7C%20REST%20API-lightgrey.svg)]()

> An end-to-end, publication-grade Clinical Decision Support System (CDSS) for automated multi-class disease diagnosis across 18 major medical pathologies using **Multinomial Logistic Regression (Softmax Regression)** with $L_2$ Ridge Regularization, Adam Optimization, mathematical Odds Ratio interpretability, and interactive web dashboard.

---

## 📌 1. Project Overview & Clinical Scope

Accurate differential diagnosis across overlapping multi-system symptoms is a critical challenge in clinical practice. This project implements a **Multinomial Logistic Regression** model designed to assess patient vitals, continuous biomarkers, and multi-system binary symptoms to generate calibrated posterior probabilities across **18 distinct medical conditions**:

| # | Disease Category | Target Pathologies Included |
|---|---|---|
| 1 | **Cardiovascular** | Essential Hypertension, Coronary Artery Disease (CAD / Angina) |
| 2 | **Respiratory** | Bronchial Asthma, COPD, Bacterial Pneumonia |
| 3 | **Infectious & Tropical** | COVID-19 Viral Infection, Dengue Fever, Malaria |
| 4 | **Gastrointestinal & Hepatic** | GERD, Acute Gastroenteritis, Fatty Liver Disease |
| 5 | **Endocrine & Metabolic** | Type 2 Diabetes Mellitus, Hypothyroidism, Hyperthyroidism |
| 6 | **Nephrology & Urology** | Chronic Kidney Disease (CKD), Acute Urinary Tract Infection (UTI) |
| 7 | **Neurology & Autoimmune** | Migraine with Aura, Rheumatoid Arthritis |

---

## 📐 2. Mathematical Formulation

### **2.1 Softmax Multinomial Link Function**
For $K = 18$ classes and $D = 47$ clinical features, the unnormalized log-odds (logits) for class $k$ given input $\mathbf{x} \in \mathbb{R}^D$ are computed as:
$$z_k = \mathbf{w}_k^T \mathbf{x} + b_k = \sum_{j=1}^D w_{kj} x_j + b_k$$

The posterior class probability is obtained via the **Softmax function**:
$$P(Y = k \mid \mathbf{x}) = \frac{\exp(z_k)}{\sum_{j=1}^K \exp(z_j)} = \frac{\exp(\mathbf{w}_k^T \mathbf{x} + b_k)}{\sum_{j=1}^K \exp(\mathbf{w}_j^T \mathbf{x} + b_j)}$$

### **2.2 Penalized Objective Function (Categorical Cross-Entropy Loss with $L_2$ Penalty)**
The parameters $\mathbf{W} \in \mathbb{R}^{D \times K}$ and $\mathbf{b} \in \mathbb{R}^K$ are estimated by minimizing:
$$J(\mathbf{W}, \mathbf{b}) = -\frac{1}{N} \sum_{i=1}^N \sum_{k=1}^K y_{ik} \log(P_{ik} + \epsilon) + \frac{\lambda}{2N} \sum_{k=1}^K \sum_{j=1}^D w_{kj}^2$$

### **2.3 Analytical Gradients**
$$\nabla_{\mathbf{W}} J = \frac{1}{N} \mathbf{X}^T (\mathbf{P} - \mathbf{Y}) + \frac{\lambda}{N} \mathbf{W}$$
$$\nabla_{\mathbf{b}} J = \frac{1}{N} \sum_{i=1}^N (\mathbf{P}_i - \mathbf{Y}_i)$$

### **2.4 Clinical Interpretability & Odds Ratios ($e^\beta$)**
The relative risk or Odds Ratio (OR) associated with unit change in feature $j$ for class $k$ is:
$$\text{Odds Ratio}_{kj} = e^{w_{kj}}$$
- $\text{OR} > 1.0$: Feature positively drives the diagnosis of disease $k$.
- $\text{OR} < 1.0$: Feature acts as an opposing or protective factor against disease $k$.

---

## 🏆 3. Empirical Evaluation & Benchmark Comparisons

Evaluated on an independent stratified test set of 1,080 patient cases:

| Model Architecture | Accuracy (%) | Precision (Macro) | Recall (Macro) | Macro F1-Score | Macro ROC-AUC |
|---|---|---|---|---|---|
| 👑 **Multinomial Logistic Regression (Tuned)** | **98.98%** | **0.9899** | **0.9898** | **0.9898** | **0.9999** |
| K-Nearest Neighbors ($k=7$) | 98.52% | 0.9854 | 0.9852 | 0.9851 | 0.9996 |
| Random Forest (Ensemble Trees) | 96.94% | 0.9698 | 0.9694 | 0.9695 | 0.9995 |
| Gaussian Naive Bayes | 96.11% | 0.9620 | 0.9611 | 0.9612 | 0.9995 |

---

## 📁 4. Project Directory Structure

```text
New ML_02/
├── app.py                     # Flask Web Application & REST API
├── requirements.txt           # Python Dependency Specifications
├── run.bat                    # 1-Click Windows Launch Script
├── README.md                  # Comprehensive Documentation
├── data/
│   └── disease_diagnosis_dataset.csv  # 5,400 Patient Records across 18 Classes
├── models/
│   ├── lr_model_weights.json  # Serialized Trained Model Parameters
│   ├── preprocessor_state.json # Standard Scaler & OneHot Encoders
│   ├── label_encoder_state.json # Class Name Encoders
│   └── model_metadata.json    # Complete Metrics, Confusion Matrix & Odds Ratios
├── notebooks/
│   └── Disease_Diagnosis_Multinomial_Logistic_Regression.ipynb # Step-by-Step Jupyter Notebook
├── src/
│   ├── disease_knowledge.py   # Clinical Guidelines, Tests, & Specialist Mappings
│   ├── generate_dataset.py    # Realistic Clinical Dataset Generator
│   ├── ml_engine.py           # Vectorized NumPy Machine Learning Core
│   ├── train_orchestrator.py  # Hyperparameter Grid Search & Benchmarking
│   └── model_utils.py         # Inference Engine, Triage & Explainability
├── static/
│   ├── css/
│   │   └── style.css          # Glassmorphic Clinical Stylesheet & Print Styles
│   └── js/
│       ├── main.js            # Interactive Patient Intake, Triage & Presets
│       └── analytics.js       # Chart.js Visualizations & Odds Ratio Explorer
└── templates/
    ├── base.html              # Core Layout, Navigation & Dynamic Theme Selector
    ├── home.html              # Project Homepage with Real-World Applications & Target Users
    ├── index.html             # Patient Diagnostic Triage & Assessment
    ├── batch.html             # Batch CSV Upload & Cohort Analysis
    ├── analytics.html         # Research Analytics & Model Evaluation Dashboard
    ├── knowledge_base.html    # Medical Reference Encyclopedia
    └── about.html             # Mathematical Theory & System Architecture
```

---

## 🚀 5. Quickstart & Installation

### **Prerequisites**
- Python 3.9+ (Windows / Linux / macOS)

### **Step 1: Open Terminal in Project Directory**
```bash
```bash
cd "D:\2nd yr Odd_sem\Machine Learning(ML)\Project_ML\ML_Project\New ML_02"
```

### **Step 2: Run 1-Click Batch File (Windows)**
Double click or run in PowerShell:
```cmd
.\run.bat
```

*Or manually launch using Python:*
```bash
python app.py
```

### **Step 3: Access Web Application & Role Profiles**
Open your web browser and navigate to:
```
http://127.0.0.1:5000
```

- **Doctor Login**: `doctor@hospital.org` (password: `doctor123`)
  - Access consultant credentials, triage admissions queue, and single/batch ML diagnosis.
- **Patient Login**: `patient@health.org` (password: `patient123`)
  - Access patient health record, baseline vitals, and diagnostic test history.

---

## 🔌 6. REST API Documentation

### **6.1 Single Patient Prediction**
- **Endpoint:** `POST /api/predict`
- **Content-Type:** `application/json`
- **Request Body Example:**
```json
{
  "age": 54,
  "gender": "Male",
  "smoking_history": "Never",
  "bmi": 31.5,
  "systolic_bp": 130,
  "diastolic_bp": 82,
  "heart_rate": 76,
  "body_temperature": 98.6,
  "spo2": 98,
  "fasting_blood_sugar": 235,
  "excessive_thirst_polydipsia": 1,
  "frequent_urination_polyuria": 1,
  "fatigue": 1
}
```
- **Response Format:**
```json
{
  "success": true,
  "data": {
    "prediction": {
      "top_disease": "Type 2 Diabetes Mellitus",
      "confidence_percentage": 99.89,
      "differential_diagnoses": [...]
    },
    "explainability": {
      "positive_indicators": [
        {"feature": "fasting_blood_sugar", "weight": 2.41, "impact": "Increases Likelihood"},
        {"feature": "excessive_thirst_polydipsia", "weight": 2.85, "impact": "Increases Likelihood"}
      ]
    },
    "triage": {
      "risk_level": "MODERATE",
      "clinical_warnings": []
    },
    "clinical_guidelines": {
      "specialist": "Endocrinologist / Diabetologist",
      "recommended_tests": ["HbA1c Test", "Fasting Plasma Glucose", "Oral Glucose Tolerance Test"]
    }
  }
}
```

---

## 📜 7. License & Academic Citation
Developed for Academic Machine Learning Research and Clinical Decision Support exploration.
