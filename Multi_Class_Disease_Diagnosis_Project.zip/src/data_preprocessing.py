"""
Data Preprocessing Pipeline for Multi-Class Disease Diagnosis
Defines schema, transformers, encoders, and train/test data splitting utilities.
"""

import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer

NUMERICAL_COLS = [
    "age", "bmi", "systolic_bp", "diastolic_bp",
    "heart_rate", "body_temperature", "spo2", "fasting_blood_sugar"
]

CATEGORICAL_COLS = [
    "gender", "smoking_history"
]

SYMPTOM_COLS = [
    "fatigue", "fever", "chills", "weight_loss", "night_sweats", "muscle_pain",
    "cough", "shortness_of_breath", "wheezing", "chest_tightness", "sore_throat", "loss_of_smell",
    "chest_pain", "palpitations", "swollen_legs_edema", "dizziness",
    "nausea", "vomiting", "abdominal_pain", "diarrhea", "heartburn", "loss_of_appetite", "jaundice",
    "headache", "light_sensitivity_photophobia", "tremors", "confusion_brain_fog",
    "joint_pain", "joint_swelling", "cold_intolerance", "heat_intolerance",
    "excessive_thirst_polydipsia", "frequent_urination_polyuria",
    "painful_urination_dysuria", "flank_pain", "dark_urine"
]

TARGET_COL = "diagnosis"

def load_data(filepath=None):
    if filepath is None:
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        filepath = os.path.join(base_dir, "data", "disease_diagnosis_dataset.csv")
    
    if not os.path.exists(filepath):
        raise FileNotFoundError(f"Dataset file not found at: {filepath}")
        
    df = pd.read_csv(filepath)
    return df

def build_preprocessor():
    """
    Creates a ColumnTransformer to handle numerical scaling,
    categorical one-hot encoding, and passthrough of binary symptoms.
    """
    preprocessor = ColumnTransformer(
        transformers=[
            ("num", StandardScaler(), NUMERICAL_COLS),
            ("cat", OneHotEncoder(drop="first", sparse_output=False, handle_unknown="ignore"), CATEGORICAL_COLS),
            ("sym", "passthrough", SYMPTOM_COLS)
        ],
        remainder="drop"
    )
    return preprocessor

def get_feature_names(preprocessor):
    """
    Extracts ordered transformed feature names from fitted ColumnTransformer.
    """
    feature_names = []
    # Numerical
    feature_names.extend(NUMERICAL_COLS)
    # Categorical OneHot
    cat_encoder = preprocessor.named_transformers_["cat"]
    cat_names = cat_encoder.get_feature_names_out(CATEGORICAL_COLS).tolist()
    feature_names.extend(cat_names)
    # Symptoms
    feature_names.extend(SYMPTOM_COLS)
    return feature_names

def prepare_train_test_data(df=None, test_size=0.2, random_state=42):
    if df is None:
        df = load_data()
        
    X = df.drop(columns=[TARGET_COL])
    y = df[TARGET_COL]
    
    # Label encode target diseases
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)
    
    # Train test split with stratification to maintain balanced classes
    X_train, X_test, y_train, y_test = train_test_split(
        X, y_encoded, test_size=test_size, random_state=random_state, stratify=y_encoded
    )
    
    # Fit preprocessor on training features
    preprocessor = build_preprocessor()
    X_train_transformed = preprocessor.fit_transform(X_train)
    X_test_transformed = preprocessor.transform(X_test)
    
    feature_names = get_feature_names(preprocessor)
    
    return {
        "X_train_raw": X_train,
        "X_test_raw": X_test,
        "X_train": X_train_transformed,
        "X_test": X_test_transformed,
        "y_train": y_train,
        "y_test": y_test,
        "preprocessor": preprocessor,
        "label_encoder": label_encoder,
        "feature_names": feature_names,
        "classes": label_encoder.classes_.tolist()
    }
