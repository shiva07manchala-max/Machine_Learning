"""
Clinical Dataset Generator for Multi-Class Disease Diagnosis
Generates a realistic, statistically grounded dataset of 5,400+ clinical patient cases
across 18 multi-class disease categories with demographic, vital sign, and symptom features.
"""

import numpy as np
import pandas as pd
import os

def generate_medical_dataset(samples_per_class=300, seed=42):
    np.random.seed(seed)
    
    diseases = [
        "Hypertension",
        "Type 2 Diabetes Mellitus",
        "Coronary Artery Disease",
        "Bronchial Asthma",
        "COPD",
        "COVID-19",
        "Bacterial Pneumonia",
        "GERD",
        "Acute Gastroenteritis",
        "Chronic Kidney Disease",
        "Fatty Liver Disease",
        "Migraine with Aura",
        "Rheumatoid Arthritis",
        "Hypothyroidism",
        "Hyperthyroidism",
        "Dengue Fever",
        "Malaria",
        "Urinary Tract Infection"
    ]
    
    symptoms_list = [
        "fatigue", "fever", "chills", "weight_loss", "night_sweats", "muscle_pain",
        "cough", "shortness_of_breath", "wheezing", "chest_tightness", "sore_throat", "loss_of_smell",
        "chest_pain", "palpitations", "swollen_legs_edema", "dizziness",
        "nausea", "vomiting", "abdominal_pain", "diarrhea", "heartburn", "loss_of_appetite", "jaundice",
        "headache", "light_sensitivity_photophobia", "tremors", "confusion_brain_fog",
        "joint_pain", "joint_swelling", "cold_intolerance", "heat_intolerance",
        "excessive_thirst_polydipsia", "frequent_urination_polyuria",
        "painful_urination_dysuria", "flank_pain", "dark_urine"
    ]
    
    records = []
    
    for disease in diseases:
        for _ in range(samples_per_class):
            # Base Patient Profiles
            gender = np.random.choice(["Male", "Female"], p=[0.5, 0.5])
            smoking_history = np.random.choice(["Never", "Former", "Current"], p=[0.55, 0.25, 0.20])
            
            # Default baseline distributions
            age = int(np.clip(np.random.normal(48, 15), 18, 88))
            bmi = round(float(np.clip(np.random.normal(25.5, 4.5), 16.0, 46.0)), 1)
            systolic_bp = int(np.clip(np.random.normal(122, 14), 85, 215))
            diastolic_bp = int(np.clip(np.random.normal(80, 9), 55, 125))
            heart_rate = int(np.clip(np.random.normal(74, 10), 45, 160))
            body_temp = round(float(np.clip(np.random.normal(98.6, 0.6), 96.5, 104.5)), 1)
            spo2 = int(np.clip(np.random.normal(98, 1.2), 75, 100))
            fbs = int(np.clip(np.random.normal(95, 15), 65, 360))
            
            # Initialize all symptom probabilities to a background baseline (0.03 to 0.08)
            symptom_probs = {s: np.random.uniform(0.02, 0.08) for s in symptoms_list}
            
            # Adjust clinical signatures based on disease pathology
            if disease == "Hypertension":
                age = int(np.clip(np.random.normal(56, 12), 30, 85))
                systolic_bp = int(np.clip(np.random.normal(162, 16), 140, 215))
                diastolic_bp = int(np.clip(np.random.normal(102, 9), 90, 125))
                symptom_probs["headache"] = 0.78
                symptom_probs["dizziness"] = 0.72
                symptom_probs["palpitations"] = 0.65
                symptom_probs["fatigue"] = 0.55

            elif disease == "Type 2 Diabetes Mellitus":
                age = int(np.clip(np.random.normal(54, 11), 32, 82))
                bmi = round(float(np.clip(np.random.normal(29.8, 4.2), 22.0, 45.0)), 1)
                fbs = int(np.clip(np.random.normal(210, 45), 135, 375))
                symptom_probs["excessive_thirst_polydipsia"] = 0.92
                symptom_probs["frequent_urination_polyuria"] = 0.90
                symptom_probs["fatigue"] = 0.82
                symptom_probs["weight_loss"] = 0.62
                symptom_probs["loss_of_appetite"] = 0.35

            elif disease == "Coronary Artery Disease":
                age = int(np.clip(np.random.normal(62, 9), 40, 88))
                smoking_history = np.random.choice(["Never", "Former", "Current"], p=[0.2, 0.45, 0.35])
                systolic_bp = int(np.clip(np.random.normal(148, 18), 115, 200))
                heart_rate = int(np.clip(np.random.normal(86, 16), 55, 140))
                symptom_probs["chest_pain"] = 0.95
                symptom_probs["chest_tightness"] = 0.88
                symptom_probs["shortness_of_breath"] = 0.82
                symptom_probs["palpitations"] = 0.70
                symptom_probs["fatigue"] = 0.65
                symptom_probs["dizziness"] = 0.50

            elif disease == "Bronchial Asthma":
                age = int(np.clip(np.random.normal(32, 14), 18, 65))
                spo2 = int(np.clip(np.random.normal(94, 3.0), 86, 99))
                heart_rate = int(np.clip(np.random.normal(88, 12), 65, 125))
                symptom_probs["wheezing"] = 0.96
                symptom_probs["shortness_of_breath"] = 0.90
                symptom_probs["chest_tightness"] = 0.85
                symptom_probs["cough"] = 0.80

            elif disease == "COPD":
                age = int(np.clip(np.random.normal(64, 8), 45, 88))
                smoking_history = np.random.choice(["Never", "Former", "Current"], p=[0.05, 0.50, 0.45])
                spo2 = int(np.clip(np.random.normal(88, 3.5), 76, 94))
                symptom_probs["cough"] = 0.94
                symptom_probs["shortness_of_breath"] = 0.95
                symptom_probs["wheezing"] = 0.82
                symptom_probs["chest_tightness"] = 0.75
                symptom_probs["fatigue"] = 0.84

            elif disease == "COVID-19":
                body_temp = round(float(np.clip(np.random.normal(101.4, 1.2), 99.5, 104.2)), 1)
                spo2 = int(np.clip(np.random.normal(92, 3.2), 82, 98))
                symptom_probs["loss_of_smell"] = 0.92
                symptom_probs["fever"] = 0.94
                symptom_probs["cough"] = 0.88
                symptom_probs["sore_throat"] = 0.78
                symptom_probs["fatigue"] = 0.86
                symptom_probs["shortness_of_breath"] = 0.68
                symptom_probs["muscle_pain"] = 0.74

            elif disease == "Bacterial Pneumonia":
                age = int(np.clip(np.random.normal(58, 15), 20, 86))
                body_temp = round(float(np.clip(np.random.normal(102.8, 1.1), 100.2, 105.0)), 1)
                spo2 = int(np.clip(np.random.normal(89, 4.0), 78, 95))
                heart_rate = int(np.clip(np.random.normal(98, 14), 78, 135))
                symptom_probs["fever"] = 0.96
                symptom_probs["chills"] = 0.90
                symptom_probs["cough"] = 0.94
                symptom_probs["chest_pain"] = 0.82
                symptom_probs["shortness_of_breath"] = 0.88
                symptom_probs["fatigue"] = 0.85

            elif disease == "GERD":
                bmi = round(float(np.clip(np.random.normal(28.2, 4.0), 20.0, 42.0)), 1)
                symptom_probs["heartburn"] = 0.96
                symptom_probs["chest_pain"] = 0.70
                symptom_probs["nausea"] = 0.65
                symptom_probs["sore_throat"] = 0.45
                symptom_probs["abdominal_pain"] = 0.40

            elif disease == "Acute Gastroenteritis":
                body_temp = round(float(np.clip(np.random.normal(100.2, 1.0), 98.6, 102.5)), 1)
                heart_rate = int(np.clip(np.random.normal(92, 12), 70, 130))
                symptom_probs["diarrhea"] = 0.96
                symptom_probs["vomiting"] = 0.92
                symptom_probs["abdominal_pain"] = 0.94
                symptom_probs["nausea"] = 0.90
                symptom_probs["fever"] = 0.60
                symptom_probs["fatigue"] = 0.75

            elif disease == "Chronic Kidney Disease":
                age = int(np.clip(np.random.normal(63, 11), 35, 87))
                systolic_bp = int(np.clip(np.random.normal(152, 16), 130, 205))
                symptom_probs["swollen_legs_edema"] = 0.92
                symptom_probs["fatigue"] = 0.90
                symptom_probs["flank_pain"] = 0.74
                symptom_probs["frequent_urination_polyuria"] = 0.78
                symptom_probs["nausea"] = 0.62
                symptom_probs["loss_of_appetite"] = 0.70

            elif disease == "Fatty Liver Disease":
                bmi = round(float(np.clip(np.random.normal(31.5, 4.5), 25.0, 46.0)), 1)
                fbs = int(np.clip(np.random.normal(135, 30), 95, 230))
                symptom_probs["fatigue"] = 0.88
                symptom_probs["abdominal_pain"] = 0.72
                symptom_probs["loss_of_appetite"] = 0.65
                symptom_probs["jaundice"] = 0.58
                symptom_probs["nausea"] = 0.52

            elif disease == "Migraine with Aura":
                gender = np.random.choice(["Male", "Female"], p=[0.25, 0.75])
                age = int(np.clip(np.random.normal(34, 10), 18, 62))
                symptom_probs["headache"] = 0.98
                symptom_probs["light_sensitivity_photophobia"] = 0.95
                symptom_probs["nausea"] = 0.82
                symptom_probs["dizziness"] = 0.70
                symptom_probs["vomiting"] = 0.45

            elif disease == "Rheumatoid Arthritis":
                gender = np.random.choice(["Male", "Female"], p=[0.25, 0.75])
                age = int(np.clip(np.random.normal(49, 12), 24, 76))
                symptom_probs["joint_pain"] = 0.98
                symptom_probs["joint_swelling"] = 0.95
                symptom_probs["fatigue"] = 0.85
                symptom_probs["muscle_pain"] = 0.65
                symptom_probs["fever"] = 0.40

            elif disease == "Hypothyroidism":
                gender = np.random.choice(["Male", "Female"], p=[0.20, 0.80])
                heart_rate = int(np.clip(np.random.normal(58, 7), 44, 72))
                bmi = round(float(np.clip(np.random.normal(29.2, 4.0), 22.0, 42.0)), 1)
                symptom_probs["cold_intolerance"] = 0.96
                symptom_probs["fatigue"] = 0.92
                symptom_probs["weight_loss"] = 0.05
                symptom_probs["joint_pain"] = 0.68
                symptom_probs["muscle_pain"] = 0.62
                symptom_probs["confusion_brain_fog"] = 0.65

            elif disease == "Hyperthyroidism":
                gender = np.random.choice(["Male", "Female"], p=[0.22, 0.78])
                heart_rate = int(np.clip(np.random.normal(108, 14), 88, 155))
                bmi = round(float(np.clip(np.random.normal(21.4, 3.0), 16.5, 27.0)), 1)
                symptom_probs["heat_intolerance"] = 0.95
                symptom_probs["tremors"] = 0.90
                symptom_probs["palpitations"] = 0.92
                symptom_probs["weight_loss"] = 0.85
                symptom_probs["excessive_thirst_polydipsia"] = 0.72
                symptom_probs["fatigue"] = 0.70

            elif disease == "Dengue Fever":
                body_temp = round(float(np.clip(np.random.normal(103.2, 1.0), 101.0, 105.2)), 1)
                symptom_probs["fever"] = 0.98
                symptom_probs["muscle_pain"] = 0.95
                symptom_probs["joint_pain"] = 0.92
                symptom_probs["headache"] = 0.90
                symptom_probs["nausea"] = 0.78
                symptom_probs["vomiting"] = 0.68
                symptom_probs["fatigue"] = 0.88

            elif disease == "Malaria":
                body_temp = round(float(np.clip(np.random.normal(103.5, 1.2), 100.8, 105.4)), 1)
                heart_rate = int(np.clip(np.random.normal(96, 12), 75, 135))
                symptom_probs["fever"] = 0.98
                symptom_probs["chills"] = 0.96
                symptom_probs["night_sweats"] = 0.94
                symptom_probs["headache"] = 0.86
                symptom_probs["fatigue"] = 0.90
                symptom_probs["muscle_pain"] = 0.80
                symptom_probs["nausea"] = 0.74

            elif disease == "Urinary Tract Infection":
                gender = np.random.choice(["Male", "Female"], p=[0.20, 0.80])
                body_temp = round(float(np.clip(np.random.normal(100.6, 1.2), 98.6, 103.5)), 1)
                symptom_probs["painful_urination_dysuria"] = 0.98
                symptom_probs["frequent_urination_polyuria"] = 0.94
                symptom_probs["flank_pain"] = 0.78
                symptom_probs["dark_urine"] = 0.82
                symptom_probs["fever"] = 0.68
                symptom_probs["nausea"] = 0.52

            # Sample binary presence for each symptom according to probability
            symptom_values = {}
            for sym in symptoms_list:
                symptom_values[sym] = 1 if np.random.rand() < symptom_probs[sym] else 0

            row = {
                "age": age,
                "gender": gender,
                "smoking_history": smoking_history,
                "bmi": bmi,
                "systolic_bp": systolic_bp,
                "diastolic_bp": diastolic_bp,
                "heart_rate": heart_rate,
                "body_temperature": body_temp,
                "spo2": spo2,
                "fasting_blood_sugar": fbs,
                **symptom_values,
                "diagnosis": disease
            }
            records.append(row)
            
    df = pd.DataFrame(records)
    # Shuffle dataset
    df = df.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    
    # Save dataset
    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, "disease_diagnosis_dataset.csv")
    df.to_csv(output_path, index=False)
    print(f"Generated {len(df)} patient records across {len(diseases)} classes.")
    print(f"Saved dataset to: {output_path}")
    return df

if __name__ == "__main__":
    generate_medical_dataset()
