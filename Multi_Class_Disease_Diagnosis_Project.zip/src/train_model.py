"""
Model Training and Evaluation Pipeline for Multi-Class Disease Diagnosis
Implements Hyperparameter-tuned Multinomial Logistic Regression with Softmax,
compares with benchmark ML models (Random Forest, SVM, Naive Bayes, Gradient Boosting),
computes comprehensive evaluation metrics (F1, Log-Loss, ROC-AUC, Confusion Matrix, Odds Ratios),
and serializes artifacts for production deployment.
"""

import os
import json
import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection import GridSearchCV, StratifiedKFold, cross_val_score
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    log_loss,
    roc_auc_score,
    confusion_matrix,
    classification_report
)

from data_preprocessing import prepare_train_test_data

def train_and_evaluate_all():
    print("==================================================")
    print("Multi-Class Disease Diagnosis - Model Training")
    print("==================================================")
    
    # 1. Prepare data
    data_dict = prepare_train_test_data()
    X_train = data_dict["X_train"]
    X_test = data_dict["X_test"]
    y_train = data_dict["y_train"]
    y_test = data_dict["y_test"]
    preprocessor = data_dict["preprocessor"]
    label_encoder = data_dict["label_encoder"]
    feature_names = data_dict["feature_names"]
    classes = data_dict["classes"]
    
    print(f"Loaded {X_train.shape[0]} training samples and {X_test.shape[0]} test samples.")
    print(f"Total features: {len(feature_names)} | Total disease classes: {len(classes)}")
    
    # 2. Hyperparameter Grid Search for Multinomial Logistic Regression
    print("\n[1/3] Tuning Hyperparameters for Multinomial Logistic Regression...")
    param_grid = {
        'C': [0.1, 0.5, 1.0, 2.0, 5.0, 10.0],
        'penalty': ['l2'],
        'solver': ['lbfgs', 'saga'],
        'max_iter': [2500]
    }
    
    base_lr = LogisticRegression(multi_class='multinomial', random_state=42)
    cv_stratified = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    
    grid_search = GridSearchCV(
        base_lr,
        param_grid=param_grid,
        cv=cv_stratified,
        scoring='f1_macro',
        n_jobs=-1,
        verbose=1
    )
    grid_search.fit(X_train, y_train)
    
    best_model = grid_search.best_estimator_
    print(f"Optimal Parameters: {grid_search.best_params_}")
    print(f"Best 5-Fold CV Macro F1: {grid_search.best_score_:.4f}")
    
    # Evaluate Best Multinomial Logistic Regression on Test Set
    y_pred = best_model.predict(X_test)
    y_proba = best_model.predict_proba(X_test)
    
    test_acc = accuracy_score(y_test, y_pred)
    test_bal_acc = balanced_accuracy_score(y_test, y_pred)
    test_prec_macro = precision_score(y_test, y_pred, average='macro', zero_division=0)
    test_rec_macro = recall_score(y_test, y_pred, average='macro', zero_division=0)
    test_f1_macro = f1_score(y_test, y_pred, average='macro', zero_division=0)
    test_f1_weighted = f1_score(y_test, y_pred, average='weighted', zero_division=0)
    test_loss = log_loss(y_test, y_proba)
    test_roc_auc = roc_auc_score(y_test, y_proba, multi_class='ovr', average='macro')
    
    print("\n--- Multinomial Logistic Regression Test Set Performance ---")
    print(f"Accuracy:          {test_acc * 100:.2f}%")
    print(f"Balanced Accuracy: {test_bal_acc * 100:.2f}%")
    print(f"Macro Precision:   {test_prec_macro:.4f}")
    print(f"Macro Recall:      {test_rec_macro:.4f}")
    print(f"Macro F1-Score:    {test_f1_macro:.4f}")
    print(f"Cross-Entropy Loss:{test_loss:.4f}")
    print(f"Macro ROC-AUC:     {test_roc_auc:.4f}")
    
    # Classification Report
    clf_report_dict = classification_report(y_test, y_pred, target_names=classes, output_dict=True)
    cm = confusion_matrix(y_test, y_pred)
    cm_normalized = confusion_matrix(y_test, y_pred, normalize='true')
    
    # 3. Model Benchmark Comparison
    print("\n[2/3] Benchmarking against Alternative ML Classifiers...")
    benchmark_models = {
        "Multinomial Logistic Regression": best_model,
        "Random Forest (150 trees)": RandomForestClassifier(n_estimators=150, random_state=42, n_jobs=-1),
        "Support Vector Machine (RBF)": SVC(probability=True, kernel='rbf', C=1.0, random_state=42),
        "Gaussian Naive Bayes": GaussianNB(),
        "Gradient Boosting Classifier": GradientBoostingClassifier(n_estimators=100, learning_rate=0.1, random_state=42)
    }
    
    benchmark_results = []
    for model_name, clf in benchmark_models.items():
        if model_name != "Multinomial Logistic Regression":
            clf.fit(X_train, y_train)
            
        preds = clf.predict(X_test)
        prob = clf.predict_proba(X_test) if hasattr(clf, "predict_proba") else None
        
        acc = accuracy_score(y_test, preds)
        prec = precision_score(y_test, preds, average='macro', zero_division=0)
        rec = recall_score(y_test, preds, average='macro', zero_division=0)
        f1 = f1_score(y_test, preds, average='macro', zero_division=0)
        auc = roc_auc_score(y_test, prob, multi_class='ovr', average='macro') if prob is not None else 0.0
        
        benchmark_results.append({
            "model_name": model_name,
            "accuracy": round(float(acc) * 100, 2),
            "precision": round(float(prec), 4),
            "recall": round(float(rec), 4),
            "f1_macro": round(float(f1), 4),
            "roc_auc": round(float(auc), 4)
        })
        print(f"-> {model_name:32s} | Acc: {acc*100:5.2f}% | F1: {f1:.4f} | ROC-AUC: {auc:.4f}")
        
    # 4. Extract Feature Coefficients & Odds Ratios per Disease Class
    print("\n[3/3] Extracting Coefficients & Explainability Matrices...")
    # coef_ shape: (n_classes, n_features)
    coefficients_matrix = best_model.coef_
    intercepts = best_model.intercept_
    
    class_feature_weights = {}
    for idx, disease_name in enumerate(classes):
        class_coefs = coefficients_matrix[idx]
        # Top 6 positive predictors & top 3 negative predictors
        sorted_indices = np.argsort(class_coefs)
        top_positive_idx = sorted_indices[-6:][::-1]
        top_negative_idx = sorted_indices[:3]
        
        top_pos = [
            {"feature": feature_names[i], "coefficient": round(float(class_coefs[i]), 4), "odds_ratio": round(float(np.exp(class_coefs[i])), 4)}
            for i in top_positive_idx
        ]
        top_neg = [
            {"feature": feature_names[i], "coefficient": round(float(class_coefs[i]), 4), "odds_ratio": round(float(np.exp(class_coefs[i])), 4)}
            for i in top_negative_idx
        ]
        
        class_feature_weights[disease_name] = {
            "intercept": round(float(intercepts[idx]), 4),
            "top_positive_features": top_pos,
            "top_negative_features": top_neg,
            "all_coefficients": {feature_names[i]: round(float(class_coefs[i]), 4) for i in range(len(feature_names))}
        }
        
    # 5. Save Artifacts
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    models_dir = os.path.join(base_dir, "models")
    os.makedirs(models_dir, exist_ok=True)
    
    joblib.dump(best_model, os.path.join(models_dir, "multinomial_logistic_model.joblib"))
    joblib.dump(preprocessor, os.path.join(models_dir, "preprocessor.joblib"))
    joblib.dump(label_encoder, os.path.join(models_dir, "label_encoder.joblib"))
    
    metadata = {
        "model_type": "Multinomial Logistic Regression (Softmax Link Function)",
        "best_hyperparameters": grid_search.best_params_,
        "classes": classes,
        "feature_names": feature_names,
        "metrics": {
            "accuracy": round(float(test_acc) * 100, 2),
            "balanced_accuracy": round(float(test_bal_acc) * 100, 2),
            "precision_macro": round(float(test_prec_macro), 4),
            "recall_macro": round(float(test_rec_macro), 4),
            "f1_macro": round(float(test_f1_macro), 4),
            "f1_weighted": round(float(test_f1_weighted), 4),
            "cross_entropy_loss": round(float(test_loss), 4),
            "roc_auc_macro": round(float(test_roc_auc), 4),
            "train_samples": int(X_train.shape[0]),
            "test_samples": int(X_test.shape[0]),
            "num_features": int(len(feature_names)),
            "num_classes": int(len(classes))
        },
        "classification_report": clf_report_dict,
        "confusion_matrix": cm.tolist(),
        "confusion_matrix_normalized": [[round(float(val), 4) for val in row] for row in cm_normalized],
        "benchmark_comparison": benchmark_results,
        "class_feature_weights": class_feature_weights
    }
    
    metadata_path = os.path.join(models_dir, "model_metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(metadata, f, indent=2)
        
    print(f"\nModel artifacts and metadata saved successfully to {models_dir}")
    print("Training Pipeline Completed Successfully!")
    return metadata

if __name__ == "__main__":
    train_and_evaluate_all()
