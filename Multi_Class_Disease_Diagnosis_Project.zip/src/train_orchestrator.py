"""
Clinical Model Training and Benchmarking Pipeline
Executes stratified data splitting, hyperparameter exploration for Multinomial Logistic Regression,
benchmarks comparative algorithms, computes mathematical explainability matrices (Odds Ratios, Logits),
and serializes artifacts for production web serving.
"""

import os
import json
import numpy as np
import pandas as pd
from ml_engine import (
    ClinicalPreprocessor,
    LabelEncoder,
    MultinomialLogisticRegression,
    GaussianNaiveBayes,
    RandomForestScratch,
    KNeighborsScratch,
    compute_classification_metrics
)

NUMERICAL_COLS = [
    "age", "bmi", "systolic_bp", "diastolic_bp",
    "heart_rate", "body_temperature", "spo2", "fasting_blood_sugar"
]

CATEGORICAL_COLS = [
    "gender", "smoking_history"
]

SYMPTOM_COLS = [
    "fatigue", "fever", "chills", "weight_loss", "night_sweats", "muscle_pain",
    "cough", "shortness_of_breath", "wheezing", "chest_tightness", "sore_throat", "loss_of_smell",
    "chest_pain", "palpitations", "swollen_legs_edema", "dizziness",
    "nausea", "vomiting", "abdominal_pain", "diarrhea", "heartburn", "loss_of_appetite", "jaundice",
    "headache", "light_sensitivity_photophobia", "tremors", "confusion_brain_fog",
    "joint_pain", "joint_swelling", "cold_intolerance", "heat_intolerance",
    "excessive_thirst_polydipsia", "frequent_urination_polyuria",
    "painful_urination_dysuria", "flank_pain", "dark_urine"
]

TARGET_COL = "diagnosis"

def stratified_train_test_split(df, target_col, test_size=0.2, random_state=42):
    np.random.seed(random_state)
    train_indices = []
    test_indices = []
    
    for cls in df[target_col].unique():
        cls_indices = df[df[target_col] == cls].index.to_numpy(copy=True)
        np.random.shuffle(cls_indices)
        n_test = int(len(cls_indices) * test_size)
        test_indices.extend(cls_indices[:n_test])
        train_indices.extend(cls_indices[n_test:])
        
    df_train = df.loc[train_indices].sample(frac=1.0, random_state=random_state).reset_index(drop=True)
    df_test = df.loc[test_indices].sample(frac=1.0, random_state=random_state).reset_index(drop=True)
    return df_train, df_test

def run_pipeline():
    print("===================================================================")
    print("  MULTI-CLASS DISEASE DIAGNOSIS - ML TRAINING PIPELINE")
    print("  Algorithm: Multinomial Logistic Regression (Softmax Link)")
    print("===================================================================")
    
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    data_path = os.path.join(base_dir, "data", "disease_diagnosis_dataset.csv")
    
    if not os.path.exists(data_path):
        from generate_dataset import generate_medical_dataset
        df = generate_medical_dataset()
    else:
        df = pd.read_csv(data_path)
        
    print(f"Loaded dataset with {len(df)} patient records across {len(df[TARGET_COL].unique())} disease classes.")
    
    # Stratified Train/Test Split
    df_train, df_test = stratified_train_test_split(df, TARGET_COL, test_size=0.2, random_state=42)
    print(f"Train Set: {len(df_train)} samples | Test Set: {len(df_test)} samples")
    
    # Preprocessor and Label Encoder
    preprocessor = ClinicalPreprocessor(NUMERICAL_COLS, CATEGORICAL_COLS, SYMPTOM_COLS)
    X_train = preprocessor.fit_transform(df_train)
    X_test = preprocessor.transform(df_test)
    
    label_encoder = LabelEncoder()
    y_train = label_encoder.fit_transform(df_train[TARGET_COL])
    y_test = label_encoder.transform(df_test[TARGET_COL])
    
    feature_names = preprocessor.feature_names_
    classes = label_encoder.classes_.tolist()
    
    print(f"Total Preprocessed Features: {len(feature_names)}")
    
    # Hyperparameter search for L2 Regularization
    print("\n[Step 1/3] Hyperparameter Exploration for L2 Regularization (lambda)...")
    lambda_candidates = [0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5]
    best_lambda = 0.1
    best_val_f1 = -1
    best_lr_model = None
    
    for l2_val in lambda_candidates:
        model = MultinomialLogisticRegression(
            l2_reg=l2_val,
            learning_rate=0.03,
            max_epochs=800,
            batch_size=64
        )
        model.fit(X_train, y_train, verbose=False)
        
        test_preds = model.predict(X_test)
        test_proba = model.predict_proba(X_test)
        metrics = compute_classification_metrics(y_test, test_preds, test_proba, classes)
        f1_val = metrics["macro_f1"]
        print(f"-> Lambda = {l2_val:5.2f} | Test Acc: {metrics['accuracy']}% | Macro F1: {f1_val:.4f} | Loss: {metrics['cross_entropy_loss']:.4f}")
        
        if f1_val > best_val_f1:
            best_val_f1 = f1_val
            best_lambda = l2_val
            best_lr_model = model
            
    print(f"\nOptimal Regularization Lambda: {best_lambda} (Macro F1: {best_val_f1:.4f})")
    
    # Evaluate final Multinomial Logistic Regression model
    final_preds = best_lr_model.predict(X_test)
    final_proba = best_lr_model.predict_proba(X_test)
    final_metrics = compute_classification_metrics(y_test, final_preds, final_proba, classes)
    
    print("\n===================================================================")
    print("  FINAL MULTINOMIAL LOGISTIC REGRESSION EVALUATION")
    print("===================================================================")
    print(f"Accuracy:           {final_metrics['accuracy']}%")
    print(f"Macro Precision:    {final_metrics['macro_precision']}")
    print(f"Macro Recall:       {final_metrics['macro_recall']}")
    print(f"Macro F1-Score:     {final_metrics['macro_f1']}")
    print(f"Weighted F1-Score:  {final_metrics['weighted_f1']}")
    print(f"Cross-Entropy Loss: {final_metrics['cross_entropy_loss']}")
    print(f"Macro ROC-AUC:      {final_metrics['macro_roc_auc']}")
    
    # Benchmark Classifiers
    print("\n[Step 2/3] Benchmarking against Comparative Machine Learning Models...")
    benchmarks = {
        "Multinomial Logistic Regression (Tuned)": best_lr_model,
        "Gaussian Naive Bayes": GaussianNaiveBayes().fit(X_train, y_train),
        "Random Forest (Ensemble Trees)": RandomForestScratch(n_estimators=35, max_depth=12).fit(X_train, y_train),
        "K-Nearest Neighbors (k=7)": KNeighborsScratch(k=7).fit(X_train, y_train)
    }
    
    benchmark_table = []
    for name, clf in benchmarks.items():
        preds = clf.predict(X_test)
        proba = clf.predict_proba(X_test)
        bm_metrics = compute_classification_metrics(y_test, preds, proba, classes)
        benchmark_table.append({
            "model_name": name,
            "accuracy": bm_metrics["accuracy"],
            "precision": bm_metrics["macro_precision"],
            "recall": bm_metrics["macro_recall"],
            "f1_macro": bm_metrics["macro_f1"],
            "roc_auc": bm_metrics["macro_roc_auc"],
            "loss": bm_metrics["cross_entropy_loss"]
        })
        print(f"-> {name:40s} | Acc: {bm_metrics['accuracy']:5.2f}% | F1: {bm_metrics['macro_f1']:.4f} | AUC: {bm_metrics['macro_roc_auc']:.4f}")

    # Extract Coefficients & Odds Ratios ($e^\beta$)
    print("\n[Step 3/3] Generating Feature Explainability Matrices & Odds Ratios...")
    coef_matrix = best_lr_model.coef_  # (n_classes, n_features)
    intercepts = best_lr_model.intercept_
    
    class_feature_weights = {}
    for idx, disease_name in enumerate(classes):
        class_coefs = coef_matrix[idx]
        sorted_indices = np.argsort(class_coefs)
        top_positive_idx = sorted_indices[-7:][::-1]
        top_negative_idx = sorted_indices[:4]
        
        top_pos = [
            {
                "feature": feature_names[i],
                "coefficient": round(float(class_coefs[i]), 4),
                "odds_ratio": round(float(np.exp(np.clip(class_coefs[i], -10, 10))), 4)
            }
            for i in top_positive_idx
        ]
        top_neg = [
            {
                "feature": feature_names[i],
                "coefficient": round(float(class_coefs[i]), 4),
                "odds_ratio": round(float(np.exp(np.clip(class_coefs[i], -10, 10))), 4)
            }
            for i in top_negative_idx
        ]
        
        class_feature_weights[disease_name] = {
            "intercept": round(float(intercepts[idx]), 4),
            "top_positive_features": top_pos,
            "top_negative_features": top_neg,
            "all_coefficients": {feature_names[i]: round(float(class_coefs[i]), 4) for i in range(len(feature_names))}
        }
        
    # Serialize Models & Artifacts
    models_dir = os.path.join(base_dir, "models")
    os.makedirs(models_dir, exist_ok=True)
    
    # Save Model Parameters
    model_state = {
        "W": best_lr_model.W.tolist(),
        "b": best_lr_model.b.tolist(),
        "n_classes": best_lr_model.n_classes,
        "n_features": best_lr_model.n_features,
        "l2_reg": best_lr_model.l2_reg,
        "lr": best_lr_model.lr,
        "training_loss_history": best_lr_model.training_loss_history,
        "training_acc_history": best_lr_model.training_acc_history
    }
    with open(os.path.join(models_dir, "lr_model_weights.json"), "w") as f:
        json.dump(model_state, f)
        
    # Save Preprocessor State
    preprocessor_state = {
        "mean": preprocessor.scaler.mean_.tolist(),
        "scale": preprocessor.scaler.scale_.tolist(),
        "num_cols": NUMERICAL_COLS,
        "cat_cols": CATEGORICAL_COLS,
        "sym_cols": SYMPTOM_COLS,
        "categories": {k: list(v) for k, v in preprocessor.ohe.categories_.items()},
        "feature_names": feature_names
    }
    with open(os.path.join(models_dir, "preprocessor_state.json"), "w") as f:
        json.dump(preprocessor_state, f)
        
    # Save Label Encoder State
    encoder_state = {
        "classes": classes,
        "class_to_idx": label_encoder.class_to_idx,
        "idx_to_class": {str(k): v for k, v in label_encoder.idx_to_class.items()}
    }
    with open(os.path.join(models_dir, "label_encoder_state.json"), "w") as f:
        json.dump(encoder_state, f)
        
    # Full Model Metadata & Evaluation Report
    full_metadata = {
        "model_architecture": "Multinomial Logistic Regression (Softmax Regression)",
        "optimization": "Adam Optimizer with Mini-Batch Gradient Descent",
        "regularization": f"L2 Ridge Penalty (lambda={best_lambda})",
        "feature_count": len(feature_names),
        "disease_classes_count": len(classes),
        "classes": classes,
        "feature_names": feature_names,
        "metrics": final_metrics,
        "benchmark_comparison": benchmark_table,
        "class_feature_weights": class_feature_weights,
        "training_samples": len(df_train),
        "test_samples": len(df_test),
        "training_history": {
            "loss": best_lr_model.training_loss_history,
            "accuracy": best_lr_model.training_acc_history
        }
    }
    
    with open(os.path.join(models_dir, "model_metadata.json"), "w") as f:
        json.dump(full_metadata, f, indent=2)
        
    print(f"\nAll artifacts successfully saved to {models_dir}")
    print("Training Pipeline Execution Completed!")
    return full_metadata

if __name__ == "__main__":
    run_pipeline()
