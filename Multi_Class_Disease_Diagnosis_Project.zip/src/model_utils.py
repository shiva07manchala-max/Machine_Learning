"""
Clinical Inference, Triage Engine & Diagnostic Decision Support
Loads serialized model weights, performs single-patient and batch predictions,
computes explainability contributions, risk severity triage, and enriches results
with clinical knowledge base guidelines.
"""

import os
import json
import numpy as np
import pandas as pd
try:
    from src.disease_knowledge import DISEASE_KNOWLEDGE_BASE, SYMPTOM_CATEGORIES, NUMERICAL_FEATURES, CATEGORICAL_FEATURES
except ImportError:
    from disease_knowledge import DISEASE_KNOWLEDGE_BASE, SYMPTOM_CATEGORIES, NUMERICAL_FEATURES, CATEGORICAL_FEATURES

class DiagnosticEngine:
    def __init__(self, models_dir=None):
        if models_dir is None:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            models_dir = os.path.join(base_dir, "models")
            
        self.models_dir = models_dir
        self._load_artifacts()

    def _load_artifacts(self):
        # 1. Load Model Weights
        with open(os.path.join(self.models_dir, "lr_model_weights.json"), "r") as f:
            self.model_state = json.load(f)
        self.W = np.array(self.model_state["W"], dtype=np.float64)  # (n_features, n_classes)
        self.b = np.array(self.model_state["b"], dtype=np.float64)  # (1, n_classes)
        
        # 2. Load Preprocessor State
        with open(os.path.join(self.models_dir, "preprocessor_state.json"), "r") as f:
            self.preprocessor_state = json.load(f)
        self.mean = np.array(self.preprocessor_state["mean"], dtype=np.float64)
        self.scale = np.array(self.preprocessor_state["scale"], dtype=np.float64)
        self.num_cols = self.preprocessor_state["num_cols"]
        self.cat_cols = self.preprocessor_state["cat_cols"]
        self.sym_cols = self.preprocessor_state["sym_cols"]
        self.categories = self.preprocessor_state["categories"]
        self.feature_names = self.preprocessor_state["feature_names"]
        
        # 3. Load Label Encoder State
        with open(os.path.join(self.models_dir, "label_encoder_state.json"), "r") as f:
            self.encoder_state = json.load(f)
        self.classes = self.encoder_state["classes"]
        self.class_to_idx = self.encoder_state["class_to_idx"]
        self.idx_to_class = {int(k): v for k, v in self.encoder_state["idx_to_class"].items()}
        
        # 4. Load Metadata
        with open(os.path.join(self.models_dir, "model_metadata.json"), "r") as f:
            self.metadata = json.load(f)

    def _preprocess_single(self, input_dict):
        # Numerical
        num_vals = [float(input_dict.get(col, 0.0)) for col in self.num_cols]
        num_arr = (np.array(num_vals) - self.mean) / self.scale
        
        # Categorical One-Hot
        cat_vals = []
        for col in self.cat_cols:
            val = str(input_dict.get(col, ""))
            cats = self.categories[col]
            usable_cats = cats[1:] if len(cats) > 1 else cats
            for c in usable_cats:
                cat_vals.append(1.0 if val == c else 0.0)
                
        # Symptoms
        sym_vals = [float(input_dict.get(col, 0)) for col in self.sym_cols]
        
        # Concatenate
        feature_vector = np.concatenate([num_arr, np.array(cat_vals), np.array(sym_vals)])
        return feature_vector.reshape(1, -1)

    def _evaluate_vital_risk(self, patient_data):
        warnings = []
        risk_level = "LOW"
        risk_score = 10  # 0 to 100
        
        systolic = float(patient_data.get("systolic_bp", 120))
        diastolic = float(patient_data.get("diastolic_bp", 80))
        heart_rate = float(patient_data.get("heart_rate", 72))
        spo2 = float(patient_data.get("spo2", 98))
        temp = float(patient_data.get("body_temperature", 98.6))
        fbs = float(patient_data.get("fasting_blood_sugar", 95))
        
        # Blood pressure checks
        if systolic >= 180 or diastolic >= 120:
            warnings.append("Hypertensive Crisis Risk: Systolic BP >= 180 or Diastolic >= 120 mmHg")
            risk_level = "CRITICAL EMERGENCY"
            risk_score = max(risk_score, 95)
        elif systolic >= 140 or diastolic >= 90:
            warnings.append("Stage 2 Hypertension Alert: BP >= 140/90 mmHg")
            risk_level = max_risk(risk_level, "HIGH")
            risk_score = max(risk_score, 65)

        # SpO2 hypoxia
        if spo2 < 90:
            warnings.append(f"Severe Hypoxemia: Blood oxygen (SpO2: {spo2}%) is critically low")
            risk_level = "CRITICAL EMERGENCY"
            risk_score = max(risk_score, 95)
        elif spo2 <= 93:
            warnings.append(f"Moderate Hypoxia: Blood oxygen (SpO2: {spo2}%) below safe threshold")
            risk_level = max_risk(risk_level, "HIGH")
            risk_score = max(risk_score, 75)

        # Body Temperature
        if temp >= 104.0:
            warnings.append(f"Hyperpyrexia Alert: High grade fever at {temp}°F")
            risk_level = max_risk(risk_level, "HIGH")
            risk_score = max(risk_score, 80)
        elif temp >= 101.5:
            warnings.append(f"Elevated Fever: Body temperature is {temp}°F")
            risk_level = max_risk(risk_level, "MODERATE")
            risk_score = max(risk_score, 50)

        # Heart Rate
        if heart_rate > 130:
            warnings.append(f"Severe Tachycardia: Resting heart rate ({heart_rate} bpm) abnormally high")
            risk_level = max_risk(risk_level, "HIGH")
            risk_score = max(risk_score, 70)
        elif heart_rate < 50:
            warnings.append(f"Bradycardia: Resting heart rate ({heart_rate} bpm) is low")
            risk_level = max_risk(risk_level, "MODERATE")
            risk_score = max(risk_score, 45)

        # Blood Sugar
        if fbs >= 280:
            warnings.append(f"Severe Hyperglycemia: Fasting blood glucose is {fbs} mg/dL")
            risk_level = max_risk(risk_level, "HIGH")
            risk_score = max(risk_score, 75)
        elif fbs < 70:
            warnings.append(f"Hypoglycemia Alert: Fasting blood glucose is low at {fbs} mg/dL")
            risk_level = max_risk(risk_level, "HIGH")
            risk_score = max(risk_score, 70)
            
        return {
            "risk_level": risk_level,
            "risk_score": risk_score,
            "clinical_warnings": warnings
        }

    def predict_patient(self, input_dict):
        """
        Executes complete multi-class inference, explainability calculation,
        and knowledge-base enrichment for a single patient record.
        """
        X = self._preprocess_single(input_dict)  # (1, n_features)
        
        # Softmax Forward Pass
        Z = np.dot(X, self.W) + self.b  # (1, n_classes)
        shifted = Z - np.max(Z, axis=1, keepdims=True)
        exp_z = np.exp(shifted)
        probas = (exp_z / np.sum(exp_z, axis=1, keepdims=True)).flatten()
        
        # Sort predictions by probability
        ranked_indices = np.argsort(-probas)
        top_idx = int(ranked_indices[0])
        top_disease = self.idx_to_class[top_idx]
        top_prob = float(probas[top_idx])
        
        # Differential Diagnoses List
        differential_diagnoses = []
        for idx in ranked_indices:
            cls_name = self.idx_to_class[int(idx)]
            prob = float(probas[idx])
            differential_diagnoses.append({
                "disease": cls_name,
                "probability": round(prob * 100, 2),
                "raw_probability": prob,
                "category": DISEASE_KNOWLEDGE_BASE.get(cls_name, {}).get("category", "General"),
                "urgency": DISEASE_KNOWLEDGE_BASE.get(cls_name, {}).get("urgency", "Moderate")
            })
            
        # Mathematical Feature Contributions for the Top Diagnosis
        # Contribution = x_j * W_{top_idx, j}
        top_class_weights = self.W[:, top_idx]
        feature_contributions = X.flatten() * top_class_weights
        
        # Sort by contribution magnitude
        sorted_contrib_idx = np.argsort(-feature_contributions)
        positive_contributors = []
        for i in sorted_contrib_idx:
            if feature_contributions[i] > 0.05:
                feat_name = self.feature_names[i]
                positive_contributors.append({
                    "feature": feat_name,
                    "label": humanize_feature_name(feat_name),
                    "contribution_score": round(float(feature_contributions[i]), 4),
                    "weight": round(float(top_class_weights[i]), 4),
                    "impact": "Increases Likelihood"
                })
                
        # Negative / deterrent features
        negative_contributors = []
        for i in sorted_contrib_idx[::-1]:
            if feature_contributions[i] < -0.05:
                feat_name = self.feature_names[i]
                negative_contributors.append({
                    "feature": feat_name,
                    "label": humanize_feature_name(feat_name),
                    "contribution_score": round(float(feature_contributions[i]), 4),
                    "weight": round(float(top_class_weights[i]), 4),
                    "impact": "Decreases Likelihood"
                })
                
        # Vital Risk Triage
        triage_info = self._evaluate_vital_risk(input_dict)
        
        # Clinical Knowledge Base Enrichment
        knowledge = DISEASE_KNOWLEDGE_BASE.get(top_disease, {
            "full_name": top_disease,
            "category": "General Medicine",
            "description": "Clinical diagnosis determined by multi-class multinomial logistic regression.",
            "urgency": "Moderate",
            "urgency_badge": "warning",
            "specialist": "General Physician",
            "recommended_tests": ["Complete Blood Count (CBC)", "Basic Metabolic Panel"],
            "precautions": ["Consult a medical doctor for definitive diagnosis and treatment plan."],
            "lifestyle_diet": "Maintain balanced hydration, adequate sleep, and nutritious diet."
        })
        
        return {
            "prediction": {
                "top_disease": top_disease,
                "confidence_percentage": round(top_prob * 100, 2),
                "confidence_score": round(top_prob, 4),
                "differential_diagnoses": differential_diagnoses[:6],  # top 6 for UI view
                "all_probabilities": differential_diagnoses
            },
            "explainability": {
                "positive_indicators": positive_contributors[:8],
                "negative_indicators": negative_contributors[:4]
            },
            "triage": triage_info,
            "clinical_guidelines": knowledge
        }

    def predict_batch_df(self, df_input):
        """
        Executes fast vectorized batch prediction on a Pandas DataFrame.
        """
        results = []
        for idx, row in df_input.iterrows():
            row_dict = row.to_dict()
            res = self.predict_patient(row_dict)
            results.append({
                "record_id": int(idx) + 1,
                "age": row_dict.get("age", "-"),
                "gender": row_dict.get("gender", "-"),
                "top_diagnosis": res["prediction"]["top_disease"],
                "confidence": f"{res['prediction']['confidence_percentage']}%",
                "risk_level": res["triage"]["risk_level"],
                "specialist": res["clinical_guidelines"]["specialist"],
                "primary_symptoms": extract_active_symptoms(row_dict)
            })
        return results


def max_risk(current, new_risk):
    order = ["LOW", "MODERATE", "HIGH", "CRITICAL EMERGENCY"]
    if order.index(new_risk) > order.index(current):
        return new_risk
    return current

def humanize_feature_name(feat_name):
    clean = feat_name.replace("_", " ").title()
    clean = clean.replace("Bp", "Blood Pressure")
    clean = clean.replace("Spo2", "Blood Oxygen (SpO2)")
    clean = clean.replace("Fbs", "Fasting Blood Sugar")
    clean = clean.replace("Bmi", "BMI")
    return clean

def extract_active_symptoms(row_dict):
    active = []
    for k, v in row_dict.items():
        if k in [
            "fatigue", "fever", "chills", "weight_loss", "night_sweats", "muscle_pain",
            "cough", "shortness_of_breath", "wheezing", "chest_tightness", "sore_throat", "loss_of_smell",
            "chest_pain", "palpitations", "swollen_legs_edema", "dizziness",
            "nausea", "vomiting", "abdominal_pain", "diarrhea", "heartburn", "loss_of_appetite", "jaundice",
            "headache", "light_sensitivity_photophobia", "tremors", "confusion_brain_fog",
            "joint_pain", "joint_swelling", "cold_intolerance", "heat_intolerance",
            "excessive_thirst_polydipsia", "frequent_urination_polyuria",
            "painful_urination_dysuria", "flank_pain", "dark_urine"
        ]:
            if str(v) in ["1", "1.0", "True", "true"]:
                active.append(k.replace("_", " ").title())
    return ", ".join(active[:4]) if active else "None reported"

# Singleton instance
_engine_instance = None
def get_diagnostic_engine():
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = DiagnosticEngine()
    return _engine_instance
