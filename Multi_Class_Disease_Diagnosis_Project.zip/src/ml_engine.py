"""
High-Performance Vectorized Machine Learning Engine
Implements Multinomial Logistic Regression (Softmax Regression with L2 Regularization & Adam Optimizer),
benchmark classifiers (Gaussian Naive Bayes, Random Forest, K-NN),
preprocessors (StandardScaler, OneHotEncoder, ColumnTransformer),
and comprehensive multi-class evaluation metrics (Accuracy, F1, Precision, Recall, ROC-AUC, Log-Loss, Confusion Matrix).
"""

import numpy as np
import pandas as pd
import json
import os

# ==========================================
# 1. PREPROCESSING & ENCODING UTILITIES
# ==========================================

class StandardScaler:
    def __init__(self):
        self.mean_ = None
        self.scale_ = None

    def fit(self, X):
        X = np.asarray(X, dtype=np.float64)
        self.mean_ = np.mean(X, axis=0)
        self.scale_ = np.std(X, axis=0)
        # Avoid division by zero
        self.scale_[self.scale_ == 0] = 1.0
        return self

    def transform(self, X):
        X = np.asarray(X, dtype=np.float64)
        return (X - self.mean_) / self.scale_

    def fit_transform(self, X):
        return self.fit(X).transform(X)


class LabelEncoder:
    def __init__(self):
        self.classes_ = None
        self.class_to_idx = {}
        self.idx_to_class = {}

    def fit(self, y):
        unique = sorted(list(set(y)))
        self.classes_ = np.array(unique)
        self.class_to_idx = {cls: idx for idx, cls in enumerate(unique)}
        self.idx_to_class = {idx: cls for idx, cls in enumerate(unique)}
        return self

    def transform(self, y):
        return np.array([self.class_to_idx[item] for item in y], dtype=np.int64)

    def fit_transform(self, y):
        return self.fit(y).transform(y)

    def inverse_transform(self, y_idx):
        return np.array([self.idx_to_class[int(idx)] for idx in y_idx])


class OneHotEncoder:
    def __init__(self, drop_first=True):
        self.drop_first = drop_first
        self.categories_ = {}
        self.feature_names_out_ = []

    def fit(self, df_cat):
        self.categories_ = {}
        self.feature_names_out_ = []
        for col in df_cat.columns:
            cats = sorted(list(df_cat[col].unique()))
            if self.drop_first and len(cats) > 1:
                usable_cats = cats[1:]
            else:
                usable_cats = cats
            self.categories_[col] = cats
            for c in usable_cats:
                self.feature_names_out_.append(f"{col}_{c}")
        return self

    def transform(self, df_cat):
        encoded_cols = []
        for col in df_cat.columns:
            cats = self.categories_[col]
            usable_cats = cats[1:] if (self.drop_first and len(cats) > 1) else cats
            for c in usable_cats:
                encoded_cols.append((df_cat[col] == c).astype(np.float64).values)
        if len(encoded_cols) == 0:
            return np.empty((len(df_cat), 0))
        return np.column_stack(encoded_cols)

    def fit_transform(self, df_cat):
        return self.fit(df_cat).transform(df_cat)


class ClinicalPreprocessor:
    def __init__(self, num_cols, cat_cols, sym_cols):
        self.num_cols = num_cols
        self.cat_cols = cat_cols
        self.sym_cols = sym_cols
        self.scaler = StandardScaler()
        self.ohe = OneHotEncoder(drop_first=True)
        self.feature_names_ = []

    def fit(self, df):
        # Numerical
        self.scaler.fit(df[self.num_cols])
        # Categorical
        self.ohe.fit(df[self.cat_cols])
        # Feature names
        self.feature_names_ = list(self.num_cols) + self.ohe.feature_names_out_ + list(self.sym_cols)
        return self

    def transform(self, df):
        X_num = self.scaler.transform(df[self.num_cols])
        X_cat = self.ohe.transform(df[self.cat_cols])
        X_sym = np.asarray(df[self.sym_cols], dtype=np.float64)
        return np.hstack([X_num, X_cat, X_sym])

    def fit_transform(self, df):
        return self.fit(df).transform(df)


# ==========================================
# 2. MULTINOMIAL LOGISTIC REGRESSION (CORE)
# ==========================================

class MultinomialLogisticRegression:
    """
    Multinomial Logistic Regression (Softmax Regression)
    with L2 Weight Decay Regularization and Adam Optimizer.
    
    Mathematical Formulation:
      Linear logit: Z = X * W + b
      Softmax: P(Y=k|x) = exp(Z_k - max(Z)) / sum_j exp(Z_j - max(Z))
      Loss: J(W, b) = - (1/N) sum_i sum_k [Y_ik * log(P_ik + eps)] + (lambda/(2N)) * sum(W^2)
      Gradients:
        dW = (1/N) * X^T * (P - Y) + (lambda/N) * W
        db = (1/N) * sum_rows(P - Y)
    """
    def __init__(self, l2_reg=0.1, learning_rate=0.01, max_epochs=1200, batch_size=64, early_stopping_tol=1e-5):
        self.l2_reg = l2_reg
        self.lr = learning_rate
        self.max_epochs = max_epochs
        self.batch_size = batch_size
        self.tol = early_stopping_tol
        
        self.W = None  # (n_features, n_classes)
        self.b = None  # (1, n_classes)
        self.n_classes = None
        self.n_features = None
        self.training_loss_history = []
        self.training_acc_history = []

    @staticmethod
    def _softmax(z):
        # Shift logits by max for numerical stability
        shifted = z - np.max(z, axis=1, keepdims=True)
        exp_z = np.exp(shifted)
        return exp_z / np.sum(exp_z, axis=1, keepdims=True)

    @staticmethod
    def _one_hot(y, n_classes):
        N = len(y)
        Y_onehot = np.zeros((N, n_classes), dtype=np.float64)
        Y_onehot[np.arange(N), y] = 1.0
        return Y_onehot

    def fit(self, X, y, X_val=None, y_val=None, verbose=False):
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64)
        N, D = X.shape
        K = len(np.unique(y))
        
        self.n_features = D
        self.n_classes = K
        
        # Initialize weights with He/Glorot normal distribution
        np.random.seed(42)
        self.W = np.random.randn(D, K) * np.sqrt(2.0 / (D + K))
        self.b = np.zeros((1, K), dtype=np.float64)
        
        # Adam optimizer state
        mW = np.zeros_like(self.W)
        vW = np.zeros_like(self.W)
        mb = np.zeros_like(self.b)
        vb = np.zeros_like(self.b)
        beta1, beta2, eps = 0.9, 0.999, 1e-8
        t_step = 0
        
        Y_onehot = self._one_hot(y, K)
        
        best_loss = float('inf')
        patience = 40
        patience_counter = 0
        best_W = self.W.copy()
        best_b = self.b.copy()
        
        self.training_loss_history = []
        self.training_acc_history = []
        
        for epoch in range(1, self.max_epochs + 1):
            # Shuffle mini-batches
            indices = np.random.permutation(N)
            X_shuffled = X[indices]
            Y_shuffled = Y_onehot[indices]
            
            for start_idx in range(0, N, self.batch_size):
                end_idx = min(start_idx + self.batch_size, N)
                X_batch = X_shuffled[start_idx:end_idx]
                Y_batch = Y_shuffled[start_idx:end_idx]
                B = len(X_batch)
                
                # Forward pass
                Z_batch = np.dot(X_batch, self.W) + self.b
                P_batch = self._softmax(Z_batch)
                
                # Gradients with L2 decay
                error = P_batch - Y_batch
                dW = (1.0 / B) * np.dot(X_batch.T, error) + (self.l2_reg / N) * self.W
                db = (1.0 / B) * np.sum(error, axis=0, keepdims=True)
                
                # Adam update
                t_step += 1
                mW = beta1 * mW + (1 - beta1) * dW
                vW = beta2 * vW + (1 - beta2) * (dW ** 2)
                mb = beta1 * mb + (1 - beta1) * db
                vb = beta2 * vb + (1 - beta2) * (db ** 2)
                
                mW_hat = mW / (1 - beta1 ** t_step)
                vW_hat = vW / (1 - beta2 ** t_step)
                mb_hat = mb / (1 - beta1 ** t_step)
                vb_hat = vb / (1 - beta2 ** t_step)
                
                self.W -= self.lr * mW_hat / (np.sqrt(vW_hat) + eps)
                self.b -= self.lr * mb_hat / (np.sqrt(vb_hat) + eps)
            
            # Compute full dataset metrics at epoch end
            Z_full = np.dot(X, self.W) + self.b
            P_full = self._softmax(Z_full)
            eps_clip = 1e-12
            ce_loss = -np.mean(np.sum(Y_onehot * np.log(np.clip(P_full, eps_clip, 1.0)), axis=1))
            l2_penalty = (self.l2_reg / (2.0 * N)) * np.sum(self.W ** 2)
            total_loss = float(ce_loss + l2_penalty)
            
            preds = np.argmax(P_full, axis=1)
            train_acc = float(np.mean(preds == y))
            
            self.training_loss_history.append(round(total_loss, 5))
            self.training_acc_history.append(round(train_acc, 5))
            
            # Validation or Early Stopping check
            if total_loss < best_loss - self.tol:
                best_loss = total_loss
                best_W = self.W.copy()
                best_b = self.b.copy()
                patience_counter = 0
            else:
                patience_counter += 1
                if patience_counter >= patience and epoch >= 100:
                    if verbose:
                        print(f"Early stopping at epoch {epoch} (Best Loss: {best_loss:.5f})")
                    break
                    
            if verbose and (epoch % 100 == 0 or epoch == 1):
                print(f"Epoch {epoch:4d}/{self.max_epochs} | Loss: {total_loss:.4f} | Accuracy: {train_acc*100:.2f}%")
                
        self.W = best_W
        self.b = best_b
        return self

    def predict_proba(self, X):
        X = np.asarray(X, dtype=np.float64)
        Z = np.dot(X, self.W) + self.b
        return self._softmax(Z)

    def predict(self, X):
        proba = self.predict_proba(X)
        return np.argmax(proba, axis=1)

    @property
    def coef_(self):
        # Return shape (n_classes, n_features) to match standard scikit convention
        return self.W.T

    @property
    def intercept_(self):
        return self.b.flatten()


# ==========================================
# 3. BENCHMARK CLASSIFIERS
# ==========================================

class GaussianNaiveBayes:
    def __init__(self):
        self.classes_ = None
        self.class_priors_ = {}
        self.means_ = {}
        self.vars_ = {}

    def fit(self, X, y):
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64)
        self.classes_ = np.unique(y)
        N = len(y)
        
        for c in self.classes_:
            X_c = X[y == c]
            self.class_priors_[c] = len(X_c) / N
            self.means_[c] = np.mean(X_c, axis=0)
            self.vars_[c] = np.var(X_c, axis=0) + 1e-4  # smoothing
        return self

    def predict_proba(self, X):
        X = np.asarray(X, dtype=np.float64)
        N = len(X)
        K = len(self.classes_)
        log_probs = np.zeros((N, K))
        
        for idx, c in enumerate(self.classes_):
            mean = self.means_[c]
            var = self.vars_[c]
            prior = self.class_priors_[c]
            # Gaussian log-likelihood
            ll = -0.5 * np.sum(np.log(2 * np.pi * var)) - 0.5 * np.sum(((X - mean) ** 2) / var, axis=1)
            log_probs[:, idx] = np.log(prior + 1e-12) + ll
            
        # Softmax over log probabilities
        shifted = log_probs - np.max(log_probs, axis=1, keepdims=True)
        exp_p = np.exp(shifted)
        return exp_p / np.sum(exp_p, axis=1, keepdims=True)

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)


class SimpleDecisionTreeNode:
    def __init__(self, depth=0, max_depth=12):
        self.depth = depth
        self.max_depth = max_depth
        self.feature_idx = None
        self.threshold = None
        self.left = None
        self.right = None
        self.predicted_class = None
        self.class_distribution = None

    def fit(self, X, y, n_classes):
        counts = np.bincount(y, minlength=n_classes)
        self.class_distribution = counts / np.sum(counts)
        self.predicted_class = np.argmax(counts)
        
        if self.depth >= self.max_depth or len(np.unique(y)) <= 1 or len(y) < 10:
            return
            
        N, D = X.shape
        best_gini = float('inf')
        best_feat = None
        best_thresh = None
        
        # Subsample features (sqrt(D)) for random forest split
        n_feats_sub = max(int(np.sqrt(D)), 4)
        feat_indices = np.random.choice(D, n_feats_sub, replace=False)
        
        for f in feat_indices:
            values = X[:, f]
            # Sample thresholds
            thresholds = np.percentile(values, [25, 50, 75])
            for t in thresholds:
                left_mask = values <= t
                right_mask = ~left_mask
                if np.sum(left_mask) == 0 or np.sum(right_mask) == 0:
                    continue
                # Gini impurity
                y_l, y_r = y[left_mask], y[right_mask]
                p_l = np.bincount(y_l, minlength=n_classes) / len(y_l)
                p_r = np.bincount(y_r, minlength=n_classes) / len(y_r)
                gini_l = 1.0 - np.sum(p_l ** 2)
                gini_r = 1.0 - np.sum(p_r ** 2)
                weighted_gini = (len(y_l) * gini_l + len(y_r) * gini_r) / N
                
                if weighted_gini < best_gini:
                    best_gini = weighted_gini
                    best_feat = f
                    best_thresh = t
                    
        if best_feat is not None:
            self.feature_idx = best_feat
            self.threshold = best_thresh
            left_mask = X[:, best_feat] <= best_thresh
            self.left = SimpleDecisionTreeNode(self.depth + 1, self.max_depth)
            self.left.fit(X[left_mask], y[left_mask], n_classes)
            self.right = SimpleDecisionTreeNode(self.depth + 1, self.max_depth)
            self.right.fit(X[~left_mask], y[~left_mask], n_classes)

    def predict_row_proba(self, x):
        if self.left is None or self.right is None:
            return self.class_distribution
        if x[self.feature_idx] <= self.threshold:
            return self.left.predict_row_proba(x)
        else:
            return self.right.predict_row_proba(x)


class RandomForestScratch:
    def __init__(self, n_estimators=30, max_depth=10, random_state=42):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.random_state = random_state
        self.trees = []
        self.n_classes = None

    def fit(self, X, y):
        np.random.seed(self.random_state)
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.int64)
        N, D = X.shape
        self.n_classes = len(np.unique(y))
        self.trees = []
        
        for _ in range(self.n_estimators):
            # Bootstrap sample
            boot_idx = np.random.choice(N, N, replace=True)
            X_b, y_b = X[boot_idx], y[boot_idx]
            tree = SimpleDecisionTreeNode(depth=0, max_depth=self.max_depth)
            tree.fit(X_b, y_b, self.n_classes)
            self.trees.append(tree)
        return self

    def predict_proba(self, X):
        X = np.asarray(X, dtype=np.float64)
        all_probs = np.zeros((len(X), self.n_classes))
        for tree in self.trees:
            probs = np.array([tree.predict_row_proba(row) for row in X])
            all_probs += probs
        all_probs /= len(self.trees)
        return all_probs

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)


class KNeighborsScratch:
    def __init__(self, k=7):
        self.k = k
        self.X_train = None
        self.y_train = None
        self.n_classes = None

    def fit(self, X, y):
        self.X_train = np.asarray(X, dtype=np.float64)
        self.y_train = np.asarray(y, dtype=np.int64)
        self.n_classes = len(np.unique(y))
        return self

    def predict_proba(self, X):
        X = np.asarray(X, dtype=np.float64)
        N = len(X)
        probas = np.zeros((N, self.n_classes))
        
        for i in range(N):
            # Euclidean distances
            dists = np.linalg.norm(self.X_train - X[i], axis=1)
            k_indices = np.argsort(dists)[:self.k]
            k_labels = self.y_train[k_indices]
            counts = np.bincount(k_labels, minlength=self.n_classes)
            probas[i] = counts / self.k
        return probas

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)


# ==========================================
# 4. EVALUATION METRICS ENGINE
# ==========================================

def compute_confusion_matrix(y_true, y_pred, n_classes):
    cm = np.zeros((n_classes, n_classes), dtype=np.int64)
    for t, p in zip(y_true, y_pred):
        cm[t, p] += 1
    return cm

def compute_classification_metrics(y_true, y_pred, y_proba, classes):
    y_true = np.asarray(y_true, dtype=np.int64)
    y_pred = np.asarray(y_pred, dtype=np.int64)
    K = len(classes)
    N = len(y_true)
    
    cm = compute_confusion_matrix(y_true, y_pred, K)
    cm_norm = np.zeros_like(cm, dtype=np.float64)
    for i in range(K):
        row_sum = np.sum(cm[i])
        cm_norm[i] = cm[i] / row_sum if row_sum > 0 else 0
        
    acc = float(np.mean(y_true == y_pred))
    
    per_class_metrics = {}
    precisions, recalls, f1s = [], [], []
    
    for k, cls_name in enumerate(classes):
        tp = float(cm[k, k])
        fp = float(np.sum(cm[:, k]) - tp)
        fn = float(np.sum(cm[k, :]) - tp)
        tn = float(N - (tp + fp + fn))
        
        prec = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        rec = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * (prec * rec) / (prec + rec) if (prec + rec) > 0 else 0.0
        spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0
        
        precisions.append(prec)
        recalls.append(rec)
        f1s.append(f1)
        
        per_class_metrics[cls_name] = {
            "precision": round(prec, 4),
            "recall": round(rec, 4),
            "f1_score": round(f1, 4),
            "specificity": round(spec, 4),
            "support": int(tp + fn)
        }
        
    macro_prec = float(np.mean(precisions))
    macro_rec = float(np.mean(recalls))
    macro_f1 = float(np.mean(f1s))
    
    # Weighted F1
    supports = [per_class_metrics[cls]["support"] for cls in classes]
    weighted_f1 = float(np.sum(np.array(f1s) * np.array(supports)) / N)
    
    # Cross-Entropy Log Loss
    eps = 1e-12
    Y_onehot = np.zeros((N, K))
    Y_onehot[np.arange(N), y_true] = 1.0
    log_loss_val = float(-np.mean(np.sum(Y_onehot * np.log(np.clip(y_proba, eps, 1.0)), axis=1)))
    
    # Multiclass One-vs-Rest ROC-AUC
    auc_scores = []
    for k in range(K):
        y_bin = (y_true == k).astype(int)
        score_k = y_proba[:, k]
        # Calculate trapezoidal AUC
        order = np.argsort(-score_k)
        y_sorted = y_bin[order]
        n_pos = np.sum(y_bin)
        n_neg = len(y_bin) - n_pos
        if n_pos > 0 and n_neg > 0:
            tp_cum = np.cumsum(y_sorted)
            fp_cum = np.cumsum(1 - y_sorted)
            tpr = tp_cum / n_pos
            fpr = fp_cum / n_neg
            if hasattr(np, 'trapezoid'):
                auc_k = float(np.trapezoid(tpr, fpr))
            elif hasattr(np, 'trapz'):
                auc_k = float(np.trapz(tpr, fpr))
            else:
                auc_k = float(np.sum((fpr[1:] - fpr[:-1]) * (tpr[1:] + tpr[:-1]) / 2.0))
            auc_scores.append(abs(auc_k))
        else:
            auc_scores.append(0.5)
            
    macro_auc = float(np.mean(auc_scores))
    
    return {
        "accuracy": round(acc * 100, 2),
        "macro_precision": round(macro_prec, 4),
        "macro_recall": round(macro_rec, 4),
        "macro_f1": round(macro_f1, 4),
        "weighted_f1": round(weighted_f1, 4),
        "cross_entropy_loss": round(log_loss_val, 4),
        "macro_roc_auc": round(macro_auc, 4),
        "confusion_matrix": cm.tolist(),
        "confusion_matrix_normalized": [[round(float(v), 4) for v in row] for row in cm_norm],
        "classification_report": per_class_metrics
    }
