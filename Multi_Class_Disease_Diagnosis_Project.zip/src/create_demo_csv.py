"""
Demo Patient Cohort CSV Generator for Batch Triage Testing
Generates a realistic demo CSV file containing 25 diverse patient cases
with varied demographics, vitals, and symptoms.
"""

import os
import pandas as pd

def create_demo_csv():
    demo_patients = [
        # 1. Type 2 Diabetes Mellitus
        {
            "patient_name": "John Doe", "age": 54, "gender": "Male", "smoking_history": "Never", "bmi": 31.8,
            "systolic_bp": 132, "diastolic_bp": 84, "heart_rate": 76, "body_temperature": 98.6, "spo2": 98,
            "fasting_blood_sugar": 240, "excessive_thirst_polydipsia": 1, "frequent_urination_polyuria": 1,
            "fatigue": 1, "weight_loss": 1, "loss_of_appetite": 0, "chest_pain": 0, "cough": 0, "fever": 0
        },
        # 2. Hypertensive Crisis / Stage 2
        {
            "patient_name": "Robert Smith", "age": 59, "gender": "Male", "smoking_history": "Current", "bmi": 29.2,
            "systolic_bp": 178, "diastolic_bp": 108, "heart_rate": 88, "body_temperature": 98.6, "spo2": 97,
            "fasting_blood_sugar": 102, "headache": 1, "dizziness": 1, "palpitations": 1, "fatigue": 1,
            "chest_pain": 0, "cough": 0, "fever": 0, "nausea": 0
        },
        # 3. Coronary Artery Disease (CAD) / Angina
        {
            "patient_name": "Michael Johnson", "age": 65, "gender": "Male", "smoking_history": "Former", "bmi": 28.0,
            "systolic_bp": 150, "diastolic_bp": 92, "heart_rate": 90, "body_temperature": 98.6, "spo2": 95,
            "fasting_blood_sugar": 115, "chest_pain": 1, "chest_tightness": 1, "shortness_of_breath": 1,
            "palpitations": 1, "fatigue": 1, "dizziness": 1, "fever": 0
        },
        # 4. Acute COVID-19 Viral Respiratory
        {
            "patient_name": "Emily Davis", "age": 34, "gender": "Female", "smoking_history": "Never", "bmi": 23.5,
            "systolic_bp": 118, "diastolic_bp": 76, "heart_rate": 94, "body_temperature": 102.4, "spo2": 92,
            "fasting_blood_sugar": 92, "loss_of_smell": 1, "fever": 1, "cough": 1, "sore_throat": 1,
            "fatigue": 1, "muscle_pain": 1, "shortness_of_breath": 1
        },
        # 5. Bacterial Pneumonia
        {
            "patient_name": "David Wilson", "age": 62, "gender": "Male", "smoking_history": "Former", "bmi": 26.5,
            "systolic_bp": 134, "diastolic_bp": 85, "heart_rate": 104, "body_temperature": 103.5, "spo2": 88,
            "fasting_blood_sugar": 98, "fever": 1, "chills": 1, "cough": 1, "chest_pain": 1,
            "shortness_of_breath": 1, "fatigue": 1, "nausea": 0
        },
        # 6. Acute Gastroenteritis
        {
            "patient_name": "Sarah Brown", "age": 28, "gender": "Female", "smoking_history": "Never", "bmi": 21.8,
            "systolic_bp": 110, "diastolic_bp": 72, "heart_rate": 96, "body_temperature": 100.8, "spo2": 99,
            "fasting_blood_sugar": 85, "diarrhea": 1, "vomiting": 1, "abdominal_pain": 1, "nausea": 1,
            "fatigue": 1, "fever": 1, "cough": 0
        },
        # 7. Bronchial Asthma
        {
            "patient_name": "James Taylor", "age": 26, "gender": "Male", "smoking_history": "Never", "bmi": 24.0,
            "systolic_bp": 120, "diastolic_bp": 78, "heart_rate": 86, "body_temperature": 98.6, "spo2": 93,
            "fasting_blood_sugar": 90, "wheezing": 1, "shortness_of_breath": 1, "chest_tightness": 1,
            "cough": 1, "fatigue": 0, "fever": 0
        },
        # 8. COPD
        {
            "patient_name": "William Anderson", "age": 67, "gender": "Male", "smoking_history": "Current", "bmi": 25.5,
            "systolic_bp": 138, "diastolic_bp": 86, "heart_rate": 88, "body_temperature": 98.6, "spo2": 87,
            "fasting_blood_sugar": 96, "cough": 1, "shortness_of_breath": 1, "wheezing": 1, "chest_tightness": 1,
            "fatigue": 1, "fever": 0
        },
        # 9. GERD (Acid Reflux)
        {
            "patient_name": "Jessica Thomas", "age": 42, "gender": "Female", "smoking_history": "Never", "bmi": 28.5,
            "systolic_bp": 124, "diastolic_bp": 80, "heart_rate": 74, "body_temperature": 98.6, "spo2": 98,
            "fasting_blood_sugar": 94, "heartburn": 1, "chest_pain": 1, "nausea": 1, "sore_throat": 1,
            "abdominal_pain": 1, "cough": 0, "fever": 0
        },
        # 10. Chronic Kidney Disease (CKD)
        {
            "patient_name": "Daniel Martinez", "age": 66, "gender": "Male", "smoking_history": "Never", "bmi": 27.5,
            "systolic_bp": 158, "diastolic_bp": 96, "heart_rate": 78, "body_temperature": 98.6, "spo2": 97,
            "fasting_blood_sugar": 110, "swollen_legs_edema": 1, "fatigue": 1, "flank_pain": 1,
            "frequent_urination_polyuria": 1, "loss_of_appetite": 1, "nausea": 1
        },
        # 11. Fatty Liver Disease (NASH)
        {
            "patient_name": "Laura Hernandez", "age": 48, "gender": "Female", "smoking_history": "Never", "bmi": 33.2,
            "systolic_bp": 130, "diastolic_bp": 84, "heart_rate": 76, "body_temperature": 98.6, "spo2": 98,
            "fasting_blood_sugar": 142, "fatigue": 1, "abdominal_pain": 1, "loss_of_appetite": 1, "jaundice": 1,
            "nausea": 1, "chest_pain": 0
        },
        # 12. Migraine with Aura
        {
            "patient_name": "Sophia Robinson", "age": 31, "gender": "Female", "smoking_history": "Never", "bmi": 22.4,
            "systolic_bp": 116, "diastolic_bp": 74, "heart_rate": 72, "body_temperature": 98.6, "spo2": 99,
            "fasting_blood_sugar": 88, "headache": 1, "light_sensitivity_photophobia": 1, "nausea": 1,
            "dizziness": 1, "vomiting": 0, "fever": 0
        },
        # 13. Rheumatoid Arthritis
        {
            "patient_name": "Karen Clark", "age": 51, "gender": "Female", "smoking_history": "Never", "bmi": 24.8,
            "systolic_bp": 122, "diastolic_bp": 78, "heart_rate": 75, "body_temperature": 99.2, "spo2": 98,
            "fasting_blood_sugar": 92, "joint_pain": 1, "joint_swelling": 1, "fatigue": 1, "muscle_pain": 1,
            "fever": 0, "headache": 0
        },
        # 14. Primary Hypothyroidism
        {
            "patient_name": "Patricia Rodriguez", "age": 46, "gender": "Female", "smoking_history": "Never", "bmi": 30.2,
            "systolic_bp": 120, "diastolic_bp": 80, "heart_rate": 54, "body_temperature": 97.8, "spo2": 98,
            "fasting_blood_sugar": 95, "cold_intolerance": 1, "fatigue": 1, "joint_pain": 1, "muscle_pain": 1,
            "confusion_brain_fog": 1, "palpitations": 0
        },
        # 15. Hyperthyroidism (Graves')
        {
            "patient_name": "Brian Lewis", "age": 38, "gender": "Male", "smoking_history": "Never", "bmi": 20.2,
            "systolic_bp": 136, "diastolic_bp": 82, "heart_rate": 112, "body_temperature": 99.1, "spo2": 98,
            "fasting_blood_sugar": 105, "heat_intolerance": 1, "tremors": 1, "palpitations": 1,
            "weight_loss": 1, "fatigue": 1, "excessive_thirst_polydipsia": 1
        },
        # 16. Dengue Fever
        {
            "patient_name": "Kevin Lee", "age": 27, "gender": "Male", "smoking_history": "Never", "bmi": 23.0,
            "systolic_bp": 114, "diastolic_bp": 72, "heart_rate": 92, "body_temperature": 103.8, "spo2": 97,
            "fasting_blood_sugar": 90, "fever": 1, "muscle_pain": 1, "joint_pain": 1, "headache": 1,
            "nausea": 1, "vomiting": 1, "fatigue": 1
        },
        # 17. Malaria (Plasmodium)
        {
            "patient_name": "Thomas Walker", "age": 35, "gender": "Male", "smoking_history": "Never", "bmi": 24.2,
            "systolic_bp": 118, "diastolic_bp": 76, "heart_rate": 98, "body_temperature": 104.2, "spo2": 96,
            "fasting_blood_sugar": 88, "fever": 1, "chills": 1, "night_sweats": 1, "headache": 1,
            "fatigue": 1, "muscle_pain": 1, "nausea": 1
        },
        # 18. Acute Urinary Tract Infection
        {
            "patient_name": "Amanda Hall", "age": 30, "gender": "Female", "smoking_history": "Never", "bmi": 22.8,
            "systolic_bp": 116, "diastolic_bp": 74, "heart_rate": 80, "body_temperature": 101.4, "spo2": 98,
            "fasting_blood_sugar": 90, "painful_urination_dysuria": 1, "frequent_urination_polyuria": 1,
            "flank_pain": 1, "dark_urine": 1, "fever": 1, "nausea": 1
        },
        # 19. Severe Hypoxemic COVID-19 Alert Case
        {
            "patient_name": "George Allen", "age": 70, "gender": "Male", "smoking_history": "Former", "bmi": 29.5,
            "systolic_bp": 142, "diastolic_bp": 88, "heart_rate": 115, "body_temperature": 102.8, "spo2": 85,
            "fasting_blood_sugar": 130, "loss_of_smell": 1, "fever": 1, "cough": 1, "shortness_of_breath": 1,
            "fatigue": 1, "muscle_pain": 1
        },
        # 20. Severe Hypertensive Crisis Alert Case
        {
            "patient_name": "Edward Young", "age": 68, "gender": "Male", "smoking_history": "Current", "bmi": 32.0,
            "systolic_bp": 195, "diastolic_bp": 125, "heart_rate": 102, "body_temperature": 98.6, "spo2": 96,
            "fasting_blood_sugar": 120, "headache": 1, "dizziness": 1, "palpitations": 1, "fatigue": 1
        }
    ]

    all_symptom_cols = [
        "fatigue", "fever", "chills", "weight_loss", "night_sweats", "muscle_pain",
        "cough", "shortness_of_breath", "wheezing", "chest_tightness", "sore_throat", "loss_of_smell",
        "chest_pain", "palpitations", "swollen_legs_edema", "dizziness",
        "nausea", "vomiting", "abdominal_pain", "diarrhea", "heartburn", "loss_of_appetite", "jaundice",
        "headache", "light_sensitivity_photophobia", "tremors", "confusion_brain_fog",
        "joint_pain", "joint_swelling", "cold_intolerance", "heat_intolerance",
        "excessive_thirst_polydipsia", "frequent_urination_polyuria",
        "painful_urination_dysuria", "flank_pain", "dark_urine"
    ]

    # Fill default 0 for any unspecified symptoms
    normalized_records = []
    for p in demo_patients:
        row = dict(p)
        for sym in all_symptom_cols:
            if sym not in row:
                row[sym] = 0
        normalized_records.append(row)

    df = pd.DataFrame(normalized_records)
    
    output_path = r"D:\2nd yr Odd_sem\Machine Learning(ML)\Project_ML\Manchala_ML\New ML_02\demo_patient_cohort.csv"
    df.to_csv(output_path, index=False)
    print(f"Demo CSV successfully created at: {output_path}")
    print(f"Total Patient Records: {len(df)} | Features: {len(df.columns)}")
    return output_path

if __name__ == "__main__":
    create_demo_csv()
