"""
Disease Knowledge Base and Clinical Decision Support Metadata
Provides comprehensive clinical reference, precautions, recommended tests,
risk classification, and specialist mapping for all target diseases.
"""

DISEASE_KNOWLEDGE_BASE = {
    "Hypertension": {
        "full_name": "Essential (Primary) Hypertension",
        "category": "Cardiovascular",
        "description": "A chronic medical condition in which the blood pressure in the arteries is persistently elevated, increasing the workload on the heart and blood vessels.",
        "urgency": "Moderate",
        "urgency_badge": "warning",
        "specialist": "Cardiologist / Internal Medicine Physician",
        "recommended_tests": [
            "24-Hour Ambulatory Blood Pressure Monitoring (ABPM)",
            "Electrocardiogram (ECG / EKG)",
            "Echocardiogram",
            "Lipid Profile & Serum Creatinine",
            "Urinalysis (Microalbuminuria)"
        ],
        "precautions": [
            "Adopt the DASH (Dietary Approaches to Stop Hypertension) diet",
            "Strictly limit dietary sodium intake to under 2,000 mg/day",
            "Engage in at least 150 minutes of moderate aerobic exercise weekly",
            "Avoid excessive alcohol, tobacco, and high caffeine consumption",
            "Maintain regular home blood pressure monitoring logs"
        ],
        "lifestyle_diet": "Emphasize potassium-rich foods (bananas, leafy greens), whole grains, lean poultry, and reduce processed sodium-heavy snacks.",
        "common_symptoms": ["headache", "dizziness", "palpitations", "fatigue", "elevated blood pressure"]
    },
    "Type 2 Diabetes Mellitus": {
        "full_name": "Type 2 Diabetes Mellitus",
        "category": "Endocrine & Metabolic",
        "description": "A metabolic disorder characterized by high blood glucose levels resulting from a progressive deficiency in insulin secretion on the background of insulin resistance.",
        "urgency": "Moderate",
        "urgency_badge": "warning",
        "specialist": "Endocrinologist / Diabetologist",
        "recommended_tests": [
            "Glycated Hemoglobin (HbA1c Test)",
            "Fasting Plasma Glucose (FPG) & Postprandial Glucose",
            "Oral Glucose Tolerance Test (OGTT)",
            "Serum Creatinine & Estimated GFR",
            "Dilated Eye Examination (Retinal Screening)"
        ],
        "precautions": [
            "Monitor blood sugar levels consistently using a glucometer or CGM",
            "Strictly regulate carbohydrate intake and avoid refined sugars",
            "Inspect feet daily for cuts, blisters, or signs of neuropathy",
            "Stay well hydrated with water and unsweetened beverages",
            "Adhere strictly to prescribed oral hypoglycemics or insulin therapy"
        ],
        "lifestyle_diet": "Focus on high-fiber complex carbohydrates (oats, legumes), lean proteins, healthy fats (avocado, nuts), and portion control.",
        "common_symptoms": ["excessive_thirst_polydipsia", "frequent_urination_polyuria", "fatigue", "weight_loss", "blurred vision"]
    },
    "Coronary Artery Disease": {
        "full_name": "Coronary Artery Disease (Ischemic Heart Disease)",
        "category": "Cardiovascular",
        "description": "Narrowing or blockage of the coronary arteries caused by atheromatous plaque buildup, reducing oxygenated blood supply to the myocardium.",
        "urgency": "Severe - High Risk",
        "urgency_badge": "danger",
        "specialist": "Interventional Cardiologist",
        "recommended_tests": [
            "12-Lead Electrocardiogram (ECG)",
            "Cardiac Biomarkers (Troponin I/T, CK-MB)",
            "Treadmill Stress Exercise Test (TMT)",
            "Coronary Computed Tomography Angiography (CCTA)",
            "Transthoracic Echocardiogram (TTE)"
        ],
        "precautions": [
            "Seek immediate emergency emergency medical evaluation if chest pressure or radiating left-arm pain occurs",
            "Completely eliminate active and passive tobacco exposure",
            "Follow a strict low-saturated-fat, Mediterranean-style cardioprotective diet",
            "Take prescribed antiplatelet and statin medications without interruption",
            "Manage psychological stress through guided relaxation techniques"
        ],
        "lifestyle_diet": "Mediterranean diet rich in extra virgin olive oil, cold-water fatty fish (salmon), walnuts, berries, and green leafy vegetables.",
        "common_symptoms": ["chest_pain", "chest_tightness", "shortness_of_breath", "palpitations", "fatigue", "dizziness"]
    },
    "Bronchial Asthma": {
        "full_name": "Bronchial Asthma (Hyperreactive Airway Disease)",
        "category": "Respiratory",
        "description": "A chronic inflammatory disorder of the airways causing episodic, reversible airflow obstruction, bronchospasm, and mucous hypersecretion.",
        "urgency": "Moderate to High",
        "urgency_badge": "warning",
        "specialist": "Pulmonologist / Allergist",
        "recommended_tests": [
            "Spirometry with Pre & Post-Bronchodilator Reversibility Testing",
            "Peak Expiratory Flow (PEF) Serial Monitoring",
            "Fractional Exhaled Nitric Oxide (FeNO)",
            "Serum Total IgE & Specific Allergen Panel",
            "Chest Radiograph (X-Ray)"
        ],
        "precautions": [
            "Always carry a quick-relief rescue inhaler (e.g., Short-Acting Beta Agonist)",
            "Identify and avoid specific environmental triggers (dust mites, pollen, pet dander, smoke)",
            "Use a spacer device with metered-dose inhalers for optimal drug deposition",
            "Get annual influenza and pneumococcal immunizations",
            "Follow an individualized written Asthma Action Plan"
        ],
        "lifestyle_diet": "Anti-inflammatory diet rich in Vitamin C, Vitamin D, and Omega-3 fatty acids. Avoid sulfites and cold air shock.",
        "common_symptoms": ["wheezing", "cough", "shortness_of_breath", "chest_tightness"]
    },
    "COPD": {
        "full_name": "Chronic Obstructive Pulmonary Disease",
        "category": "Respiratory",
        "description": "A progressive, persistent lung condition characterized by chronic airflow limitation resulting from emphysema and chronic bronchitis, predominantly driven by noxious particle exposure.",
        "urgency": "High",
        "urgency_badge": "danger",
        "specialist": "Pulmonologist",
        "recommended_tests": [
            "Post-Bronchodilator Spirometry (FEV1/FVC < 0.70 confirmation)",
            "High-Resolution Computed Tomography (HRCT) of Chest",
            "Arterial Blood Gas (ABG) Analysis",
            "Alpha-1 Antitrypsin (AAT) Serum Level",
            "6-Minute Walk Test (6MWT)"
        ],
        "precautions": [
            "Immediate and permanent cessation of all tobacco and vaping products",
            "Enroll in structured pulmonary rehabilitation and breathing exercise training (pursed-lip breathing)",
            "Maintain strict adherence to long-acting dual bronchodilators (LABA/LAMA)",
            "Avoid exposure to indoor biomass smoke, chemical fumes, and heavy outdoor smog",
            "Keep emergency supplemental oxygen guidelines readily available if prescribed"
        ],
        "lifestyle_diet": "High-protein, moderate-fat, lower-carb meals divided into smaller, frequent portions to prevent diaphragm crowding.",
        "common_symptoms": ["chronic cough", "shortness_of_breath", "wheezing", "chest_tightness", "fatigue", "hypoxia"]
    },
    "COVID-19": {
        "full_name": "COVID-19 (SARS-CoV-2 Acute Respiratory Infection)",
        "category": "Infectious Disease",
        "description": "A contagious viral illness caused by the SARS-CoV-2 coronavirus, exhibiting varying presentations from mild upper respiratory illness to severe bilateral viral pneumonia.",
        "urgency": "Moderate to High",
        "urgency_badge": "danger",
        "specialist": "Infectious Disease Specialist / General Physician",
        "recommended_tests": [
            "Reverse Transcription Polymerase Chain Reaction (RT-PCR) Swab",
            "Rapid SARS-CoV-2 Antigen Test",
            "Pulse Oximetry continuous monitoring (SpO2 target > 94%)",
            "Inflammatory Biomarkers (CRP, D-Dimer, Ferritin)",
            "Chest X-ray / High-Resolution CT Chest (if desaturating)"
        ],
        "precautions": [
            "Self-isolate immediately in a well-ventilated room to protect family and community",
            "Monitor SpO2 levels at 4-6 hour intervals; seek hospital care if SpO2 drops below 93%",
            "Stay thoroughly hydrated with electrolyte solutions, warm broths, and water",
            "Practice proning (lying on stomach) to enhance alveolar recruitment if mildly breathless",
            "Wear a certified N95 / FFP2 mask when near healthcare providers"
        ],
        "lifestyle_diet": "Immune-supportive diet with zinc, vitamin C, warm liquids, honey-lemon ginger tea, and complete physical rest.",
        "common_symptoms": ["fever", "cough", "loss_of_smell", "shortness_of_breath", "fatigue", "sore_throat", "body_aches"]
    },
    "Bacterial Pneumonia": {
        "full_name": "Community-Acquired Bacterial Pneumonia",
        "category": "Respiratory & Infectious",
        "description": "An acute lower respiratory tract infection causing inflammatory consolidation of the alveolar spaces, commonly caused by Streptococcus pneumoniae or atypical pathogens.",
        "urgency": "High",
        "urgency_badge": "danger",
        "specialist": "Pulmonologist / Infectious Disease Physician",
        "recommended_tests": [
            "Chest Radiograph (PA & Lateral Views showing consolidation)",
            "Sputum Gram Stain and Culture & Sensitivity",
            "Complete Blood Count (CBC) with Differential (Leukocytosis check)",
            "Blood Cultures (x2 sets before antibiotics)",
            "Serum C-Reactive Protein (CRP) & Procalcitonin"
        ],
        "precautions": [
            "Complete the entire prescribed antibacterial regimen without skipping doses",
            "Rest continuously and stay well-hydrated to thin respiratory secretions",
            "Use antipyretics to control high fever under physician guidance",
            "Report immediately if experiencing severe pleuritic chest pain or cyanosis",
            "Follow up with a repeat chest X-ray in 4 to 6 weeks post-recovery"
        ],
        "lifestyle_diet": "Nutrient-dense warm broths, steamed vegetables, citrus fruits, and adequate fluids to assist expectoration.",
        "common_symptoms": ["high fever", "productive cough with rust/green sputum", "chills", "chest_pain", "shortness_of_breath"]
    },
    "GERD": {
        "full_name": "Gastroesophageal Reflux Disease",
        "category": "Gastroenterology",
        "description": "A digestive disorder that occurs when gastric acidic contents repeatedly flow back up into the tube connecting your mouth and stomach (esophagus).",
        "urgency": "Mild to Moderate",
        "urgency_badge": "info",
        "specialist": "Gastroenterologist",
        "recommended_tests": [
            "Upper Gastrointestinal Endoscopy (Esophagogastroduodenoscopy - EGD)",
            "24-Hour Ambulatory Esophageal pH/Impedance Monitoring",
            "Esophageal High-Resolution Manometry",
            "Barium Swallow Fluoroscopy"
        ],
        "precautions": [
            "Avoid lying flat within 3 hours after eating a meal",
            "Elevate the head of your bed by 6 to 8 inches",
            "Avoid known trigger foods (spicy dishes, citrus, chocolate, mint, tomato sauces, coffee)",
            "Eat smaller, more frequent meals rather than large heavy dinners",
            "Avoid tight-fitting garments around the abdomen"
        ],
        "lifestyle_diet": "Alkaline and non-acidic foods (bananas, melons, oatmeal, ginger, steamed poultry, non-citrus fruits).",
        "common_symptoms": ["heartburn", "acid regurgitation", "chest_pain", "nausea", "sore_throat"]
    },
    "Acute Gastroenteritis": {
        "full_name": "Acute Gastroenteritis (Infectious Diarrhea / Food Poisoning)",
        "category": "Gastrointestinal & Infectious",
        "description": "An acute inflammation of the mucous membranes of the gastrointestinal tract, causing sudden onset diarrhea, cramping, and vomiting.",
        "urgency": "Moderate",
        "urgency_badge": "warning",
        "specialist": "Gastroenterologist / General Physician",
        "recommended_tests": [
            "Stool Routine Examination, Microscopy & Stool Culture",
            "Stool Multiplex PCR for Enteric Pathogens",
            "Serum Electrolytes (Sodium, Potassium, Chloride, Bicarbonate)",
            "Blood Urea Nitrogen (BUN) and Serum Creatinine (assess dehydration)"
        ],
        "precautions": [
            "Prioritize Oral Rehydration Solutions (ORS) to rapidly replace lost electrolytes",
            "Strictly follow hand hygiene with soap and water after restroom use",
            "Avoid dairy, greasy, highly seasoned, and sugary items during the acute phase",
            "Rest the digestive tract by sipping fluids slowly rather than gulping",
            "Seek urgent medical attention if blood is present in stool or if vomiting prevents oral fluid retention"
        ],
        "lifestyle_diet": "BRAT diet (Bananas, Rice, Applesauce, Toast), clear broths, coconut water, and plain saltine crackers.",
        "common_symptoms": ["diarrhea", "vomiting", "abdominal_pain", "nausea", "fever", "fatigue"]
    },
    "Chronic Kidney Disease": {
        "full_name": "Chronic Kidney Disease (CKD)",
        "category": "Nephrology & Renal",
        "description": "A progressive loss of renal function over months or years, leading to accumulation of fluid and metabolic waste products in the body.",
        "urgency": "High",
        "urgency_badge": "danger",
        "specialist": "Nephrologist",
        "recommended_tests": [
            "Serum Creatinine and Estimated Glomerular Filtration Rate (eGFR)",
            "Urine Albumin-to-Creatinine Ratio (uACR)",
            "Renal Ultrasonography (Bilateral Kidney size and corticomedullary differentiation)",
            "Serum Electrolytes, Calcium, Phosphate, and Parathyroid Hormone (PTH)",
            "Complete Blood Count (detecting renal anemia)"
        ],
        "precautions": [
            "Strict blood pressure management targeting < 130/80 mmHg",
            "Avoid nephrotoxic substances (NSAID painkillers like ibuprofen, aminoglycosides, IV radiocontrast)",
            "Consult a renal dietitian to restrict dietary sodium, potassium, and phosphorus as indicated",
            "Monitor daily weight to detect rapid fluid retention or edema",
            "Tight glycemic control if diabetes is an underlying etiology"
        ],
        "lifestyle_diet": "Renal-friendly diet: moderate controlled protein, low sodium (< 2g/day), restricted phosphorus and potassium based on lab values.",
        "common_symptoms": ["swollen_legs_edema", "fatigue", "frequent_urination_polyuria", "nausea", "loss_of_appetite", "flank_pain"]
    },
    "Fatty Liver Disease": {
        "full_name": "Metabolic Dysfunction-Associated Steatohepatitis / Fatty Liver",
        "category": "Hepatology & Metabolic",
        "description": "Excess accumulation of lipid droplets within hepatocytes, potentially progressing to inflammation, steatohepatitis, and hepatic fibrosis.",
        "urgency": "Moderate",
        "urgency_badge": "warning",
        "specialist": "Hepatologist / Gastroenterologist",
        "recommended_tests": [
            "Liver Function Tests (ALT, AST, ALP, GGT, Total Bilirubin)",
            "Abdominal Ultrasound / Transient Elastography (FibroScan)",
            "FIB-4 Index or NAFLD Fibrosis Score calculation",
            "Lipid Panel and Fasting Insulin/Glucose Resistance Index (HOMA-IR)",
            "Viral Hepatitis Serology (HBsAg, Anti-HCV to rule out co-infections)"
        ],
        "precautions": [
            "Aim for a gradual, sustainable 7-10% body weight reduction",
            "Completely abstain from alcohol consumption to prevent compounded hepatic injury",
            "Engage in combined aerobic and resistance training 4-5 days per week",
            "Eliminate fructose-sweetened beverages and ultra-processed fast foods",
            "Review current medications to avoid unnecessary hepatotoxic supplements"
        ],
        "lifestyle_diet": "Plant-forward Mediterranean diet with green vegetables, olive oil, walnuts, legumes, and unsweetened black coffee.",
        "common_symptoms": ["fatigue", "abdominal_pain", "loss_of_appetite", "jaundice", "nausea"]
    },
    "Migraine with Aura": {
        "full_name": "Migraine with Aura (Neurological Cephalea)",
        "category": "Neurology",
        "description": "A complex neurovascular headache disorder characterized by recurrent attacks of moderate-to-severe throbbing unilateral head pain often preceded by reversible neurological aura symptoms.",
        "urgency": "Mild to Moderate",
        "urgency_badge": "info",
        "specialist": "Neurologist / Headache Specialist",
        "recommended_tests": [
            "Comprehensive Neurological Physical Examination",
            "Magnetic Resonance Imaging (MRI) of Brain with/without contrast (rule out structural lesions)",
            "Headache Diary & Trigger Pattern Tracking",
            "Fundoscopic Examination (rule out papilledema)"
        ],
        "precautions": [
            "Rest in a dark, quiet, temperature-controlled room during acute episodes",
            "Apply cold compresses or gel ice packs over the forehead and neck",
            "Take prescribed abortive medications (e.g., Triptans) at the earliest onset of the headache phase",
            "Maintain consistent sleep schedules and avoid skipping meals",
            "Identify and steer clear of personal dietary triggers (aged cheeses, MSG, nitrates, artificial sweeteners)"
        ],
        "lifestyle_diet": "Hydration with magnesium-rich foods (spinach, pumpkin seeds, almonds), regular meal timing, minimizing caffeine withdrawal.",
        "common_symptoms": ["headache", "light_sensitivity_photophobia", "nausea", "dizziness", "visual aura flashes"]
    },
    "Rheumatoid Arthritis": {
        "full_name": "Rheumatoid Arthritis (Autoimmune Polyarthritis)",
        "category": "Rheumatology & Immunology",
        "description": "A systemic autoimmune inflammatory disorder that primarily targets synovial joints, causing symmetric erosive synovitis, cartilage destruction, and systemic comorbidities.",
        "urgency": "Moderate to High",
        "urgency_badge": "warning",
        "specialist": "Rheumatologist",
        "recommended_tests": [
            "Rheumatoid Factor (RF) and Anti-Cyclic Citrullinated Peptide (Anti-CCP)",
            "Erythrocyte Sedimentation Rate (ESR) and C-Reactive Protein (CRP)",
            "Radiographs (X-Rays) of Hands, Wrists, and Feet",
            "Musculoskeletal Ultrasound / MRI of Affected Joints",
            "Complete Blood Count and Comprehensive Metabolic Panel"
        ],
        "precautions": [
            "Early initiation and strict compliance with Disease-Modifying Antirheumatic Drugs (DMARDs)",
            "Engage in low-impact joint-friendly exercises (swimming, cycling, water aerobics)",
            "Use warm water baths or hot packs in the morning to relieve joint stiffness",
            "Balance periods of physical activity with sufficient joint rest",
            "Protect joint alignment with ergonomic assistive tools"
        ],
        "lifestyle_diet": "Mediterranean anti-inflammatory diet rich in omega-3 fish oils, turmeric, berries, leafy greens, and avoiding trans fats.",
        "common_symptoms": ["joint_pain", "joint_swelling", "morning stiffness", "fatigue", "fever"]
    },
    "Hypothyroidism": {
        "full_name": "Primary Hypothyroidism (Hashimoto's Thyroiditis)",
        "category": "Endocrinology",
        "description": "An endocrine disorder in which the thyroid gland produces insufficient thyroid hormones (T3 and T4), leading to a general slowing of metabolic processes.",
        "urgency": "Mild to Moderate",
        "urgency_badge": "info",
        "specialist": "Endocrinologist",
        "recommended_tests": [
            "Serum Thyroid Stimulating Hormone (TSH)",
            "Free Thyroxine (Free T4) and Free Triiodothyronine (Free T3)",
            "Anti-Thyroid Peroxidase (Anti-TPO) and Anti-Thyroglobulin (Anti-Tg) Antibodies",
            "Lipid Panel (evaluating secondary hypercholesterolemia)",
            "Thyroid Ultrasonography"
        ],
        "precautions": [
            "Take levothyroxine replacement therapy first thing in the morning on an empty stomach with plain water",
            "Wait at least 30 to 60 minutes after taking thyroid medication before eating breakfast or drinking coffee",
            "Avoid taking calcium, iron, or antacid supplements within 4 hours of thyroid hormone dosing",
            "Have TSH levels rechecked every 6 to 12 weeks during dose adjustments",
            "Protect against cold temperatures and dry skin"
        ],
        "lifestyle_diet": "Balanced iodine and selenium-rich nutrition (brazil nuts, eggs, fish). Avoid excessive raw goitrogens in extreme quantities.",
        "common_symptoms": ["fatigue", "cold_intolerance", "weight_gain", "joint_pain", "muscle_pain", "depression"]
    },
    "Hyperthyroidism": {
        "full_name": "Hyperthyroidism (Graves' Disease / Toxic Thyrotoxicosis)",
        "category": "Endocrinology",
        "description": "A condition characterized by hypermetabolism and elevated serum levels of free thyroid hormones due to thyroid gland overactivity.",
        "urgency": "Moderate to High",
        "urgency_badge": "warning",
        "specialist": "Endocrinologist",
        "recommended_tests": [
            "Serum Thyroid Stimulating Hormone (TSH - typically suppressed)",
            "Free T4 and Free T3 assays",
            "Thyroid-Stimulating Immunoglobulin (TSI) / TSH Receptor Antibodies (TRAb)",
            "Radioactive Iodine Uptake and Thyroid Scintigraphy Scan",
            "Baseline Electrocardiogram (ECG - screen for sinus tachycardia / atrial fibrillation)"
        ],
        "precautions": [
            "Adhere diligently to antithyroid medications (e.g., Methimazole or Propylthiouracil) or beta-blockers",
            "Avoid excessive iodine-rich supplements, kelp, or iodinated radiocontrast agents",
            "Report immediately if rapid resting heart rate, fever, or severe agitation develops (thyroid storm alert)",
            "Wear sunglasses and use artificial tears if experiencing thyroid eye disease symptoms",
            "Avoid strenuous high-intensity exertion until hormone levels stabilize"
        ],
        "lifestyle_diet": "Calorie-adequate nutrient-rich diet with cruciferous vegetables, calcium, vitamin D, and minimal stimulants (avoid caffeine).",
        "common_symptoms": ["heat_intolerance", "weight_loss", "palpitations", "tremors", "excessive_thirst_polydipsia", "fatigue", "anxiety"]
    },
    "Dengue Fever": {
        "full_name": "Dengue Fever (Breakbone Viral Fever)",
        "category": "Infectious & Tropical Diseases",
        "description": "A mosquito-borne viral infection caused by Dengue Virus (DENV) transmitted by Aedes mosquitoes, characterized by high fever, severe arthralgia/myalgia, and thrombocytopenia.",
        "urgency": "High",
        "urgency_badge": "danger",
        "specialist": "Infectious Disease Specialist / General Physician",
        "recommended_tests": [
            "Dengue NS1 Antigen ELISA (Day 1-5 of illness)",
            "Dengue IgM and IgG Antibody Serology (Day 5+ of illness)",
            "Serial Complete Blood Count (CBC) with Hematocrit and Platelet Count",
            "Liver Function Tests and Coagulation Profile (PT/INR)",
            "Abdominal Ultrasound (detecting gallbladder wall edema or ascites)"
        ],
        "precautions": [
            "Avoid aspirin, ibuprofen, and other NSAIDs entirely as they dramatically increase hemorrhagic risk; use paracetamol exclusively",
            "Ensure vigorous oral hydration with coconut water, electrolyte solutions, and oral rehydration salts",
            "Monitor platelet count and hematocrit daily during the critical defervescence phase (Days 3-7)",
            "Watch vigilantly for danger warning signs: severe abdominal pain, persistent vomiting, mucosal bleeding, lethargy",
            "Use mosquito netting and insect repellents to prevent secondary transmission"
        ],
        "lifestyle_diet": "Hydrating fluids, papaya leaf extract (under clinical advice), coconut water, pomegranate juice, and soft easily digestible meals.",
        "common_symptoms": ["high fever", "muscle_pain", "joint_pain", "headache", "nausea", "vomiting", "rash"]
    },
    "Malaria": {
        "full_name": "Malaria (Plasmodium Parasitic Infection)",
        "category": "Infectious & Tropical Diseases",
        "description": "A life-threatening protozoal disease transmitted by the bite of an infected female Anopheles mosquito, featuring cyclical fever paroxysms, rigors, and hemolytic anemia.",
        "urgency": "High",
        "urgency_badge": "danger",
        "specialist": "Infectious Disease Specialist",
        "recommended_tests": [
            "Thick and Thin Peripheral Blood Smear Examination (Gold Standard for species and parasitemia)",
            "Malaria Rapid Diagnostic Test (RDT - Pf HRP-2 / Pan-pLDH)",
            "Complete Blood Count (detecting anemia and thrombocytopenia)",
            "Serum Bilirubin and Lactate Dehydrogenase (LDH - assessing hemolysis)",
            "Blood Glucose and Renal Function Tests"
        ],
        "precautions": [
            "Initiate Artemisinin-based Combination Therapy (ACT) promptly upon positive laboratory confirmation",
            "Complete the entire prescribed antimalarial course without premature discontinuation",
            "Manage fever spikes with prescribed antipyretics and lukewarm sponge baths",
            "Maintain high fluid intake to assist renal clearance and counter dehydration from diaphoresis",
            "Sleep under long-lasting insecticide-treated mosquito nets (ITNs)"
        ],
        "lifestyle_diet": "High-protein recovery diet, iron-rich foods, fresh fruit juices, and electrolyte-replenishing broths.",
        "common_symptoms": ["fever", "chills", "night_sweats", "headache", "fatigue", "nausea", "muscle_pain"]
    },
    "Urinary Tract Infection": {
        "full_name": "Urinary Tract Infection / Acute Pyelonephritis",
        "category": "Urology & Nephrology",
        "description": "An infection affecting the urinary system (bladder, urethra, or kidneys), most commonly caused by uropathogenic Escherichia coli bacteria.",
        "urgency": "Moderate",
        "urgency_badge": "warning",
        "specialist": "Urologist / General Physician",
        "recommended_tests": [
            "Urine Routine & Microscopic Examination (Pyuria, Bacteriuria, Nitrites, Leukocyte Esterase)",
            "Urine Culture and Antibiotic Sensitivity Testing",
            "Complete Blood Count and Renal Function Tests",
            "Kidney-Ureter-Bladder (KUB) Ultrasound (rule out hydronephrosis or calculi)"
        ],
        "precautions": [
            "Drink plenty of water (at least 2.5 to 3 liters daily) to naturally flush bacteria from the urinary tract",
            "Do not delay urination; empty bladder completely and frequently",
            "Wipe from front to back after bowel movements to prevent bacterial spread",
            "Complete the entire prescribed antibiotic cycle even if symptoms subside early",
            "Avoid irritants like harsh soaps, synthetic undergarments, and excessive caffeine"
        ],
        "lifestyle_diet": "Cranberry extract or unsweetened juice, probiotic yogurt, abundant water, and avoiding bladder irritants.",
        "common_symptoms": ["painful_urination_dysuria", "frequent_urination_polyuria", "flank_pain", "fever", "nausea", "dark_urine"]
    }
}

SYMPTOM_CATEGORIES = {
    "General & Systemic": [
        {"id": "fatigue", "label": "Fatigue & Weakness", "description": "Persistent tiredness and low energy"},
        {"id": "fever", "label": "Fever / Elevated Body Temperature", "description": "Body temperature elevated above 99.5°F (37.5°C)"},
        {"id": "chills", "label": "Chills & Shivering", "description": "Involuntary shivering and sensation of cold"},
        {"id": "weight_loss", "label": "Unexplained Weight Loss", "description": "Unintended drop in body mass"},
        {"id": "night_sweats", "label": "Night Sweats / Profuse Diaphoresis", "description": "Severe sweating during night or sleep"},
        {"id": "muscle_pain", "label": "Myalgia (Muscle Aches & Pain)", "description": "Generalized soreness or pain in muscles"}
    ],
    "Respiratory System": [
        {"id": "cough", "label": "Cough (Dry or Productive)", "description": "Persistent coughing reflex"},
        {"id": "shortness_of_breath", "label": "Dyspnea (Shortness of Breath)", "description": "Difficulty breathing or feeling breathless"},
        {"id": "wheezing", "label": "Wheezing / Whistling Breath", "description": "High-pitched whistling sound during exhalation"},
        {"id": "chest_tightness", "label": "Chest Tightness & Constriction", "description": "Sensation of heavy band or constriction around chest"},
        {"id": "sore_throat", "label": "Pharyngitis (Sore Throat)", "description": "Pain, scratchiness, or irritation in throat"},
        {"id": "loss_of_smell", "label": "Anosmia / Loss of Smell & Taste", "description": "Partial or complete loss of olfactory sense"}
    ],
    "Cardiovascular System": [
        {"id": "chest_pain", "label": "Angina / Chest Pain", "description": "Discomfort, pressure, or aching in the chest"},
        {"id": "palpitations", "label": "Palpitations & Racing Heart", "description": "Sensations of pounding, fluttering, or rapid heartbeats"},
        {"id": "swollen_legs_edema", "label": "Peripheral Edema (Swollen Legs/Feet)", "description": "Fluid retention causing swelling in ankles or legs"},
        {"id": "dizziness", "label": "Dizziness / Lightheadedness", "description": "Feeling faint, woozy, or unsteady on feet"}
    ],
    "Gastrointestinal & Hepatic": [
        {"id": "nausea", "label": "Nausea & Queasiness", "description": "Sensation of an urge to vomit"},
        {"id": "vomiting", "label": "Emesis (Vomiting)", "description": "Forceful expulsion of stomach contents"},
        {"id": "abdominal_pain", "label": "Abdominal Cramping & Pain", "description": "Discomfort or sharp pain in abdominal region"},
        {"id": "diarrhea", "label": "Diarrhea (Loose/Frequent Stools)", "description": "Frequent watery bowel movements"},
        {"id": "heartburn", "label": "Pyrosis (Acid Heartburn / Regurgitation)", "description": "Burning sensation rising from stomach to chest"},
        {"id": "loss_of_appetite", "label": "Anorexia (Loss of Appetite)", "description": "Reduced desire to eat meals"},
        {"id": "jaundice", "label": "Jaundice (Yellowing of Eyes & Skin)", "description": "Yellow discoloration due to elevated bilirubin"}
    ],
    "Neurological & Sensory": [
        {"id": "headache", "label": "Cephalea (Headache)", "description": "Pain or throbbing in head or cranial region"},
        {"id": "light_sensitivity_photophobia", "label": "Photophobia (Light Sensitivity)", "description": "Discomfort or pain triggered by bright lights"},
        {"id": "tremors", "label": "Fine Involuntary Tremors", "description": "Shaking hands or fingers at rest/action"},
        {"id": "confusion_brain_fog", "label": "Cognitive Fog / Disorientation", "description": "Difficulty concentrating, memory haze, or mild confusion"}
    ],
    "Musculoskeletal & Endocrine": [
        {"id": "joint_pain", "label": "Arthralgia (Joint Pain)", "description": "Aching or stiffness in knees, wrists, fingers, etc."},
        {"id": "joint_swelling", "label": "Joint Swelling & Inflammation", "description": "Visible enlargement or warmth around joints"},
        {"id": "cold_intolerance", "label": "Extreme Cold Intolerance", "description": "Excessive sensitivity to cold temperatures"},
        {"id": "heat_intolerance", "label": "Extreme Heat Intolerance", "description": "Excessive perspiration and sensitivity to warm environments"},
        {"id": "excessive_thirst_polydipsia", "label": "Polydipsia (Excessive Constant Thirst)", "description": "Unquenchable need to drink water"},
        {"id": "frequent_urination_polyuria", "label": "Polyuria (Frequent / Night Urination)", "description": "Abnormally high frequency or volume of urine"}
    ],
    "Urinary & Renal": [
        {"id": "painful_urination_dysuria", "label": "Dysuria (Burning / Painful Urination)", "description": "Sharp stinging or discomfort while urinating"},
        {"id": "flank_pain", "label": "Flank & Lower Back Pain", "description": "Deep ache in the side of torso or lower back"},
        {"id": "dark_urine", "label": "Dark / Tea-Colored Urine", "description": "Abnormally dark or amber colored urine"}
    ]
}

NUMERICAL_FEATURES = [
    {"id": "age", "label": "Patient Age", "unit": "years", "min": 18, "max": 95, "default": 45, "step": 1},
    {"id": "bmi", "label": "Body Mass Index (BMI)", "unit": "kg/m²", "min": 15.0, "max": 50.0, "default": 24.5, "step": 0.1},
    {"id": "systolic_bp", "label": "Systolic Blood Pressure", "unit": "mmHg", "min": 80, "max": 220, "default": 120, "step": 1},
    {"id": "diastolic_bp", "label": "Diastolic Blood Pressure", "unit": "mmHg", "min": 50, "max": 130, "default": 80, "step": 1},
    {"id": "heart_rate", "label": "Resting Heart Rate", "unit": "bpm", "min": 40, "max": 180, "default": 72, "step": 1},
    {"id": "body_temperature", "label": "Body Temperature", "unit": "°F", "min": 95.0, "max": 105.5, "default": 98.6, "step": 0.1},
    {"id": "spo2", "label": "Blood Oxygen Saturation (SpO2)", "unit": "%", "min": 70, "max": 100, "default": 98, "step": 1},
    {"id": "fasting_blood_sugar", "label": "Fasting Blood Sugar", "unit": "mg/dL", "min": 60, "max": 380, "default": 95, "step": 1}
]

CATEGORICAL_FEATURES = [
    {"id": "gender", "label": "Biological Sex", "options": ["Male", "Female"]},
    {"id": "smoking_history", "label": "Smoking Status", "options": ["Never", "Former", "Current"]}
]
