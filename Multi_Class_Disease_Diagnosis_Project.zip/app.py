"""
Multi-Class Disease Diagnosis Web Application
Flask Application serving clinical decision support APIs, interactive diagnostic assessment,
batch patient CSV processing, research analytics dashboards, and medical knowledge base.
"""

import os
import io
import json
import pandas as pd
from flask import Flask, render_template, request, jsonify, send_file, Response, redirect, url_for, session, flash

from src.model_utils import get_diagnostic_engine, humanize_feature_name
from src.disease_knowledge import (
    DISEASE_KNOWLEDGE_BASE,
    SYMPTOM_CATEGORIES,
    NUMERICAL_FEATURES,
    CATEGORICAL_FEATURES
)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'clinical-ml-diagnostic-secret-key-2026'

from functools import wraps

# Pre-configured clinical users with roles
USERS = {
    "doctor@hospital.org": {
        "password": "doctor123",
        "name": "Dr. Sarah Mitchell, MD",
        "role": "doctor",
        "title": "Senior Consultant - Internal Medicine & Cardiology",
        "hospital": "Metropolitan University Health System",
        "license_id": "MD-849204-CLIN",
        "department": "Cardiology & General Medicine",
        "active_cases": 14,
        "phone": "+1 (555) 349-2910",
        "email": "doctor@hospital.org",
        "avatar": "fa-user-doctor",
        "specialties": ["Hypertension Management", "Coronary Artery Disease", "Type 2 Diabetes Screening", "Clinical Triage"]
    },
    "patient@health.org": {
        "password": "patient123",
        "name": "Alex Morgan",
        "role": "patient",
        "title": "Registered Patient",
        "patient_id": "PT-993821",
        "age": 48,
        "gender": "Male",
        "blood_group": "O+",
        "primary_physician": "Dr. Sarah Mitchell, MD",
        "emergency_contact": "+1 (555) 782-9014",
        "email": "patient@health.org",
        "avatar": "fa-user",
        "vitals_summary": {
            "blood_pressure": "128/82 mmHg",
            "heart_rate": "74 bpm",
            "blood_sugar": "104 mg/dL",
            "spo2": "98%"
        },
        "recent_tests": [
            {"date": "2026-09-15", "test": "Lipid Profile & Serum Creatinine", "status": "Completed - Normal"},
            {"date": "2026-08-20", "test": "Fasting Blood Glucose", "status": "Completed - 104 mg/dL"},
            {"date": "2026-07-02", "test": "12-Lead Electrocardiogram (ECG)", "status": "Completed - Normal Sinus"}
        ]
    }
}

# Access control decorator - only authenticated users can access clinical tools
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('user'):
            flash("Access restricted. Please sign in or register to access clinical diagnostic tools.", "warning")
            return redirect(url_for('login', next=request.path))
        return f(*args, **kwargs)
    return decorated_function

# Initialize diagnostic engine
engine = get_diagnostic_engine()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    # If already logged in, redirect directly to profile or next
    next_url = request.args.get('next') or request.form.get('next')
    active_tab = request.args.get('tab', 'signin')

    if request.method == 'POST':
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '').strip()

        user = USERS.get(email)
        if user and user['password'] == password:
            session['user'] = {
                'email': email,
                'name': user['name'],
                'role': user['role'],
                'title': user.get('title', 'Registered User'),
                'avatar': user.get('avatar', 'fa-user')
            }
            flash(f"Welcome back, {user['name']}!", "success")
            if next_url and next_url.startswith('/') and next_url != '/login' and next_url != '/logout':
                return redirect(next_url)
            return redirect(url_for('profile'))
        else:
            flash("Invalid email or password. Please verify credentials or register a new account.", "danger")

    return render_template('login.html', next=next_url, active_tab=active_tab)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return redirect(url_for('login', tab='register'))

    email = request.form.get('email', '').strip().lower()
    password = request.form.get('password', '').strip()
    name = request.form.get('name', '').strip()
    role = request.form.get('role', 'doctor').strip().lower()
    next_url = request.form.get('next')

    if not email or not password or not name:
        flash("Please complete all required fields (Name, Email, and Password).", "danger")
        return redirect(url_for('login', tab='register'))

    if email in USERS:
        flash("An account with this email address already exists. Please sign in.", "warning")
        return redirect(url_for('login', tab='signin'))

    # Build new user account based on role
    if role == 'doctor':
        hospital = request.form.get('hospital', '').strip() or "Metropolitan Medical Center"
        department = request.form.get('department', '').strip() or "General Medicine & Triage"
        license_id = request.form.get('license_id', '').strip() or f"MD-{abs(hash(email)) % 900000 + 100000}-CLIN"
        specialty = request.form.get('specialty', '').strip() or "Internal Medicine"
        phone = request.form.get('phone', '').strip() or "+1 (555) 234-5678"

        doc_name = name if name.lower().startswith("dr.") else f"Dr. {name}"
        USERS[email] = {
            "password": password,
            "name": doc_name,
            "role": "doctor",
            "title": f"Attending Physician - {department}",
            "hospital": hospital,
            "license_id": license_id,
            "department": department,
            "active_cases": 1,
            "phone": phone,
            "email": email,
            "avatar": "fa-user-doctor",
            "specialties": [specialty, "Differential Diagnosis", "Clinical Decision Support"]
        }
    else:
        # Patient role
        age = request.form.get('age', '35').strip()
        gender = request.form.get('gender', 'Not Specified').strip()
        blood_group = request.form.get('blood_group', 'O+').strip()
        emergency_contact = request.form.get('emergency_contact', '').strip() or "+1 (555) 911-0000"
        phone = request.form.get('phone', '').strip() or "+1 (555) 888-1234"

        try:
            parsed_age = int(age)
        except ValueError:
            parsed_age = 35

        USERS[email] = {
            "password": password,
            "name": name,
            "role": "patient",
            "title": "Registered Patient",
            "patient_id": f"PT-{abs(hash(email)) % 900000 + 100000}",
            "age": parsed_age,
            "gender": gender,
            "blood_group": blood_group,
            "primary_physician": "Dr. Sarah Mitchell, MD",
            "emergency_contact": emergency_contact,
            "phone": phone,
            "email": email,
            "avatar": "fa-user",
            "vitals_summary": {
                "blood_pressure": "120/80 mmHg",
                "heart_rate": "72 bpm",
                "blood_sugar": "96 mg/dL",
                "spo2": "99%"
            },
            "recent_tests": [
                {"date": "2026-10-01", "test": "Initial Health Baseline Screening", "status": "Registered - Normal"}
            ]
        }

    # Automatically authenticate and log in newly registered user
    user_record = USERS[email]
    session['user'] = {
        'email': email,
        'name': user_record['name'],
        'role': user_record['role'],
        'title': user_record['title'],
        'avatar': user_record['avatar']
    }

    flash(f"Account registered successfully! Welcome to MediLogit AI, {user_record['name']}.", "success")
    if next_url and next_url.startswith('/') and next_url != '/login' and next_url != '/logout':
        return redirect(next_url)
    return redirect(url_for('profile'))

@app.route('/logout')
def logout():
    session.pop('user', None)
    flash("You have been successfully logged out.", "info")
    return redirect(url_for('home'))

@app.route('/profile')
@login_required
def profile():
    user_email = session['user']['email']
    user_data = USERS.get(user_email)
    if not user_data:
        session.pop('user', None)
        return redirect(url_for('login'))

    return render_template('profile.html', user=user_data)

@app.route('/diagnosis')
@login_required
def index():
    return render_template(
        'index.html',
        symptom_categories=SYMPTOM_CATEGORIES,
        numerical_features=NUMERICAL_FEATURES,
        categorical_features=CATEGORICAL_FEATURES,
        diseases=list(DISEASE_KNOWLEDGE_BASE.keys())
    )

@app.route('/batch')
@login_required
def batch():
    return render_template('batch.html')

@app.route('/analytics')
@login_required
def analytics():
    return render_template('analytics.html', metadata=engine.metadata)

@app.route('/knowledge-base')
@login_required
def knowledge_base():
    return render_template(
        'knowledge_base.html',
        knowledge_base=DISEASE_KNOWLEDGE_BASE
    )

@app.route('/about')
def about():
    return render_template('about.html')

# ==========================================
# REST API ENDPOINTS
# ==========================================

@app.route('/api/predict', methods=['POST'])
def api_predict():
    if not session.get('user'):
        return jsonify({"success": False, "error": "Access restricted. Please sign in to run clinical predictions."}), 401
    try:
        data = request.get_json(force=True)
        if not data:
            return jsonify({"success": False, "error": "No input payload provided"}), 400
            
        result = engine.predict_patient(data)
        return jsonify({"success": True, "data": result})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/batch-predict', methods=['POST'])
def api_batch_predict():
    if not session.get('user'):
        return jsonify({"success": False, "error": "Access restricted. Please sign in to run batch triage."}), 401
    try:
        if 'file' not in request.files:
            return jsonify({"success": False, "error": "No CSV file uploaded"}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({"success": False, "error": "Selected file is empty"}), 400
            
        df = pd.read_csv(file)
        results = engine.predict_batch_df(df)
        
        # Summary class counts
        class_counts = {}
        for r in results:
            diag = r["top_diagnosis"]
            class_counts[diag] = class_counts.get(diag, 0) + 1
            
        return jsonify({
            "success": True,
            "total_records": len(results),
            "results": results,
            "class_distribution": class_counts
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/sample-csv')
def api_sample_csv():
    """Generates a downloadable sample CSV template with 5 pre-filled patient cases."""
    sample_patients = [
        {
            "age": 58, "gender": "Male", "smoking_history": "Current", "bmi": 31.2,
            "systolic_bp": 168, "diastolic_bp": 102, "heart_rate": 84, "body_temperature": 98.6,
            "spo2": 98, "fasting_blood_sugar": 115, "headache": 1, "dizziness": 1, "palpitations": 1,
            "fatigue": 1, "chest_pain": 0, "cough": 0, "fever": 0, "dysuria": 0
        },
        {
            "age": 52, "gender": "Female", "smoking_history": "Never", "bmi": 29.5,
            "systolic_bp": 128, "diastolic_bp": 82, "heart_rate": 76, "body_temperature": 98.6,
            "spo2": 98, "fasting_blood_sugar": 245, "excessive_thirst_polydipsia": 1,
            "frequent_urination_polyuria": 1, "fatigue": 1, "weight_loss": 1, "headache": 0, "cough": 0
        },
        {
            "age": 64, "gender": "Male", "smoking_history": "Former", "bmi": 27.0,
            "systolic_bp": 145, "diastolic_bp": 92, "heart_rate": 88, "body_temperature": 98.6,
            "spo2": 96, "fasting_blood_sugar": 105, "chest_pain": 1, "chest_tightness": 1,
            "shortness_of_breath": 1, "palpitations": 1, "fatigue": 1, "dizziness": 1
        },
        {
            "age": 35, "gender": "Male", "smoking_history": "Never", "bmi": 24.0,
            "systolic_bp": 120, "diastolic_bp": 78, "heart_rate": 92, "body_temperature": 102.4,
            "spo2": 92, "fasting_blood_sugar": 92, "loss_of_smell": 1, "fever": 1, "cough": 1,
            "sore_throat": 1, "fatigue": 1, "muscle_pain": 1
        },
        {
            "age": 28, "gender": "Female", "smoking_history": "Never", "bmi": 22.5,
            "systolic_bp": 115, "diastolic_bp": 75, "heart_rate": 78, "body_temperature": 100.8,
            "spo2": 98, "fasting_blood_sugar": 88, "painful_urination_dysuria": 1,
            "frequent_urination_polyuria": 1, "flank_pain": 1, "dark_urine": 1, "fever": 1
        }
    ]
    df_sample = pd.DataFrame(sample_patients)
    output = io.StringIO()
    df_sample.to_csv(output, index=False)
    
    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": "attachment;filename=sample_patient_records.csv"}
    )

@app.route('/api/model-metadata')
def api_model_metadata():
    return jsonify(engine.metadata)

@app.route('/api/disease-info/<disease_name>')
def api_disease_info(disease_name):
    info = DISEASE_KNOWLEDGE_BASE.get(disease_name)
    if not info:
        return jsonify({"success": False, "error": "Disease not found"}), 404
    return jsonify({"success": True, "data": info})

if __name__ == '__main__':
    print("==================================================")
    print("Multi-Class Disease Diagnosis Clinical Web Server")
    print("Running at: http://127.0.0.1:5000")
    print("==================================================")
    app.run(host='0.0.0.0', port=5000, debug=True)
